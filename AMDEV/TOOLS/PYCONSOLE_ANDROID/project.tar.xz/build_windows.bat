@echo off
setlocal
where gradle >nul 2>nul
if errorlevel 1 (
 echo Debes instalar Android Studio y Gradle, o compilar desde GitHub Actions.
 exit /b 1
)
gradle :app:assembleDebug
if errorlevel 1 exit /b 1
echo APK: app\build\outputs\apk\debug\app-debug.apk
