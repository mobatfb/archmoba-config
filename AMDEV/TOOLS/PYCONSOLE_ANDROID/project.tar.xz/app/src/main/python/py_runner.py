"""Run a selected Python source file in the Android app's private workspace.

Python executes in a separate Android Service process so Stop can terminate
unresponsive code without killing the app's user interface.
"""

import os
import sys
import tokenize
import traceback


class _Output:
    encoding = "utf-8"
    errors = "replace"

    def __init__(self, bridge):
        self.bridge = bridge

    def write(self, value):
        value = str(value)
        if value:
            self.bridge.output(value)
        return len(value)

    def flush(self):
        self.bridge.flushNow()

    def isatty(self):
        return False


class _Input:
    encoding = "utf-8"
    errors = "replace"

    def __init__(self, bridge):
        self.bridge = bridge

    def readline(self, size=-1):
        response = self.bridge.requestInput()
        if response is None:
            return ""
        line = str(response) + "\n"
        return line if size is None or size < 0 else line[:size]

    def isatty(self):
        return False


def execute_file(path, app_dir, bridge):
    """Return 0 when successful, or 1 for an unhandled script exception."""
    workspace = os.path.realpath(os.path.join(app_dir, "workspace"))
    script_path = os.path.realpath(path)
    if os.path.commonpath((workspace, script_path)) != workspace:
        bridge.output("[Error] File is not in the workspace.\n")
        return 1
    if not script_path.endswith(".py") or not os.path.isfile(script_path):
        bridge.output("[Error] Select an existing .py file.\n")
        return 1

    previous_stdout, previous_stderr, previous_stdin = sys.stdout, sys.stderr, sys.stdin
    previous_argv = sys.argv[:]
    previous_cwd = os.getcwd()
    previous_path = sys.path[:]
    sys.stdout = _Output(bridge)
    sys.stderr = _Output(bridge)
    sys.stdin = _Input(bridge)
    sys.argv = [script_path]
    sys.path.insert(0, workspace)
    try:
        os.chdir(workspace)
        with tokenize.open(script_path) as source_file:
            source = source_file.read()
        namespace = {
            "__name__": "__main__",
            "__file__": script_path,
            "__package__": None,
            "__builtins__": __builtins__,
        }
        exec(compile(source, script_path, "exec"), namespace, namespace)
        return 0
    except SystemExit as ex:
        if ex.code in (None, 0):
            return 0
        if isinstance(ex.code, str):
            print(ex.code, file=sys.stderr)
        else:
            print("Program exited with status:", ex.code, file=sys.stderr)
        return 1
    except BaseException:
        traceback.print_exc()
        return 1
    finally:
        try:
            sys.stdout.flush()
            sys.stderr.flush()
        finally:
            sys.stdout, sys.stderr, sys.stdin = previous_stdout, previous_stderr, previous_stdin
            sys.argv = previous_argv
            sys.path[:] = previous_path
            os.chdir(previous_cwd)
