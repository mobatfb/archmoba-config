package com.archmoba.pyconsole;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Native Android adaptation of the original Tkinter AMDEV launcher.
 * Reads the same AMDEV/apps.json and individual config.json files as AMDEV/app.py.
 * Its interface does not depend on Tkinter, a desktop X11 display or a subprocess.
 */
public final class AMDEVActivity extends Activity {
    private static final String REPO_RAW = "https://raw.githubusercontent.com/mobatfb/archmoba-dev/";
    private static final String CATALOG_URL = REPO_RAW + "main/AMDEV/apps.json";
    private static final String SELF_URL = REPO_RAW + "main/AMDEV/app.py";
    private static final int BG = Color.rgb(23, 25, 28);
    private static final int CARD = Color.rgb(34, 37, 42);
    private static final int PANEL = Color.rgb(28, 32, 37);
    private static final int EDGE = Color.rgb(58, 63, 70);
    private static final int TEAL = Color.rgb(23, 102, 132);
    private static final int RED = Color.rgb(255, 54, 54);
    private static final int WHITE = Color.rgb(244, 246, 249);
    private static final int MUTED = Color.rgb(169, 175, 184);
    private static final int GREEN = Color.rgb(89, 213, 167);
    private static final int MAX_JSON_BYTES = 256 * 1024;
    private static final Pattern SAFE_REPO_PATH = Pattern.compile("[A-Za-z0-9._/-]{1,250}");

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ArrayList<JSONObject> apps = new ArrayList<>();
    private LinearLayout listContainer;
    private TextView catalogStatus;
    private TextView selectedLabel;
    private TextView versionLabel;
    private TextView floatingSelection;
    private Button refreshButton;
    private String selectedId = "";
    private String catalogSource = "Incluido";
    private boolean fetching = false;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        selectedId = preferences().getString("selected_app_id", "");
        render();
        loadBundledOrCachedCatalog();
        refreshCatalog();
    }

    private SharedPreferences preferences() {
        return getSharedPreferences("amdev_android", MODE_PRIVATE);
    }

    private int dp(float n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }

    private TextView text(String s, int sp, int color, boolean strong) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (strong) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private GradientDrawable shape(int background, int border, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(background);
        d.setCornerRadius(dp(radius));
        if (border != Color.TRANSPARENT) d.setStroke(dp(1), border);
        return d;
    }

    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private void render() {
        FrameLayout full = new FrameLayout(this);
        full.setBackgroundColor(BG);
        setContentView(full);

        LinearLayout screen = column();
        full.addView(screen, new FrameLayout.LayoutParams(-1, -1));

        ScrollView scroll = new ScrollView(this);
        scroll.setClipToPadding(false);
        scroll.setFillViewport(false);
        screen.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        LinearLayout body = column();
        body.setPadding(dp(18), dp(19), dp(18), dp(128));
        scroll.addView(body, new ScrollView.LayoutParams(-1, -2));

        LinearLayout header = row();
        body.addView(header);
        TextView monogram = text("AM", 20, WHITE, true);
        monogram.setGravity(Gravity.CENTER);
        monogram.setBackground(shape(TEAL, EDGE, 11));
        LinearLayout.LayoutParams monogramP = new LinearLayout.LayoutParams(dp(52), dp(52));
        monogramP.rightMargin = dp(13);
        header.addView(monogram, monogramP);

        LinearLayout brand = column();
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        TextView title = text("ArchMomaDEV", 20, WHITE, true);
        title.setSingleLine(true);
        brand.addView(title);
        TextView sub = text("AMDEV  /  ANDROID", 10, GREEN, true);
        sub.setLetterSpacing(.13f);
        sub.setPadding(0, dp(3), 0, 0);
        brand.addView(sub);

        TextView menu = text("\u22ee", 27, WHITE, true);
        menu.setGravity(Gravity.CENTER);
        menu.setContentDescription("Opciones de AMDEV");
        menu.setBackground(shape(PANEL, EDGE, 10));
        header.addView(menu, new LinearLayout.LayoutParams(dp(44), dp(44)));
        menu.setOnClickListener(this::openTopMenu);

        TextView line = text("REPOSITORIO ARCHMOBA  /  PYTHON 3", 10, MUTED, true);
        line.setLetterSpacing(.08f);
        line.setPadding(0, dp(25), 0, dp(9));
        body.addView(line);

        TextView mainTitle = text("Aplicaciones", 32, WHITE, true);
        body.addView(mainTitle);
        TextView intro = text("Selecciona aplicaciones de AMDEV desde GitHub. El lanzador ya tiene una interfaz Android; los modulos de escritorio se abren como codigo Python.", 13, MUTED, false);
        intro.setPadding(0, dp(8), 0, dp(15));
        intro.setLineSpacing(dp(3), 1f);
        body.addView(intro);

        LinearLayout statusBox = row();
        statusBox.setPadding(dp(12), dp(11), dp(10), dp(11));
        statusBox.setBackground(shape(PANEL, EDGE, 10));
        body.addView(statusBox);
        catalogStatus = text("Catalogo incluido / comprobando GitHub...", 11, MUTED, false);
        statusBox.addView(catalogStatus, new LinearLayout.LayoutParams(0, -2, 1));
        refreshButton = button("\u21bb", PANEL, WHITE);
        refreshButton.setContentDescription("Recargar aplicaciones desde GitHub");
        statusBox.addView(refreshButton, new LinearLayout.LayoutParams(dp(43), dp(36)));
        refreshButton.setOnClickListener(v -> refreshCatalog());

        TextView sectionTitle = text("CATALOGO", 11, MUTED, true);
        sectionTitle.setLetterSpacing(.15f);
        sectionTitle.setPadding(dp(3), dp(21), 0, dp(7));
        body.addView(sectionTitle);
        listContainer = column();
        body.addView(listContainer, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout selectedPanel = column();
        selectedPanel.setPadding(dp(14), dp(13), dp(14), dp(13));
        selectedPanel.setBackground(shape(PANEL, EDGE, 11));
        LinearLayout.LayoutParams panelP = new LinearLayout.LayoutParams(-1, -2);
        panelP.topMargin = dp(19);
        body.addView(selectedPanel, panelP);
        TextView selectedTitle = text("SELECCION ACTUAL", 10, GREEN, true);
        selectedTitle.setLetterSpacing(.08f);
        selectedPanel.addView(selectedTitle);
        selectedLabel = text("Ninguna aplicacion seleccionada", 14, WHITE, true);
        selectedLabel.setPadding(0, dp(6), 0, dp(2));
        selectedPanel.addView(selectedLabel);
        TextView help = text("Toca una tarjeta para ver informacion y obtener su script. Toca AMDEV para abrir el menu rapido.", 12, MUTED, false);
        help.setPadding(0, dp(8), 0, 0);
        help.setLineSpacing(dp(2), 1f);
        selectedPanel.addView(help);

        versionLabel = text("AMDEV 1.0.23  /  Android 0.3", 11, MUTED, false);
        versionLabel.setPadding(dp(3), dp(18), 0, 0);
        body.addView(versionLabel);

        LinearLayout bottom = row();
        bottom.setPadding(dp(16), dp(9), dp(16), dp(10));
        bottom.setBackground(shape(PANEL, EDGE, 0));
        screen.addView(bottom, new LinearLayout.LayoutParams(-1, dp(70)));
        TextView tabApps = text("\u25a6  Aplicaciones", 14, WHITE, true);
        tabApps.setGravity(Gravity.CENTER);
        tabApps.setBackground(shape(TEAL, Color.TRANSPARENT, 10));
        bottom.addView(tabApps, new LinearLayout.LayoutParams(0, dp(49), 1f));
        TextView tabConsole = text("\u2328  Python 3", 14, WHITE, true);
        tabConsole.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tabP = new LinearLayout.LayoutParams(0, dp(49), 1f);
        tabP.leftMargin = dp(9);
        bottom.addView(tabConsole, tabP);
        tabConsole.setOnClickListener(v -> openConsole(null, false));

        LinearLayout floating = column();
        floating.setGravity(Gravity.CENTER);
        floating.setBackground(shape(TEAL, RED, 13));
        floating.setElevation(dp(7));
        TextView floatingTitle = text("AMDEV", 16, WHITE, true);
        floatingTitle.setGravity(Gravity.CENTER);
        floating.addView(floatingTitle);
        floatingSelection = text("Sin seleccion", 9, WHITE, false);
        floatingSelection.setSingleLine(true);
        floatingSelection.setGravity(Gravity.CENTER);
        floating.addView(floatingSelection);
        FrameLayout.LayoutParams floatP = new FrameLayout.LayoutParams(dp(120), dp(66), Gravity.RIGHT | Gravity.BOTTOM);
        floatP.setMargins(0, 0, dp(18), dp(82));
        full.addView(floating, floatP);
        floating.setContentDescription("Menu flotante AMDEV");
        floating.setOnClickListener(v -> openQuickMenu());
        floating.setOnLongClickListener(v -> { openQuickMenu(); return true; });
    }

    private Button button(String title, int background, int color) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(title);
        b.setTextColor(color);
        b.setTextSize(13);
        b.setBackground(shape(background, EDGE, 9));
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(6), 0, dp(6), 0);
        return b;
    }

    private void setCatalogStatus(String message, int color) {
        catalogStatus.setText(message);
        catalogStatus.setTextColor(color);
    }

    private void loadBundledOrCachedCatalog() {
        String json = preferences().getString("catalog_cache", "");
        if (json.isEmpty()) {
            try (InputStream in = getAssets().open("amdev_catalog.json")) {
                json = new String(readBounded(in, MAX_JSON_BYTES), StandardCharsets.UTF_8);
            } catch (Exception error) {
                json = "{\"apps\":[]}";
            }
            catalogSource = "Incluido";
        } else {
            catalogSource = "Cache";
        }
        try {
            applyCatalog(json);
        } catch (Exception ignored) {
            apps.clear();
            refreshCards();
        }
        setCatalogStatus("Catalogo: " + catalogSource + "  |  sincronizando...", MUTED);
    }

    private static byte[] readBounded(InputStream in, int maxBytes) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int n;
        while ((n = in.read(buffer)) != -1) {
            if (out.size() + n > maxBytes) throw new IllegalArgumentException("Respuesta demasiado grande.");
            out.write(buffer, 0, n);
        }
        return out.toByteArray();
    }

    private static String safeRepoPath(String path) {
        if (path == null) throw new IllegalArgumentException("Ruta no definida.");
        String clean = path.replace('\\', '/').trim();
        if (clean.startsWith("/") || clean.startsWith(".") || clean.contains("..")
                || clean.contains("//") || clean.contains(":") || !SAFE_REPO_PATH.matcher(clean).matches()) {
            throw new IllegalArgumentException("Ruta del repositorio no valida.");
        }
        return clean;
    }

    private static String fetchText(String url) throws Exception {
        // Only fixed URLs assembled from our repository are accepted here.
        HttpURLConnection cn = (HttpURLConnection) new URL(url).openConnection();
        cn.setConnectTimeout(10000);
        cn.setReadTimeout(18000);
        cn.setInstanceFollowRedirects(false);
        cn.setRequestProperty("User-Agent", "AMDEV-Android/0.3");
        cn.setRequestProperty("Cache-Control", "no-cache");
        try {
            if (cn.getResponseCode() != 200) throw new IllegalArgumentException("GitHub HTTP " + cn.getResponseCode());
            try (InputStream in = cn.getInputStream()) {
                return new String(readBounded(in, MAX_JSON_BYTES), StandardCharsets.UTF_8);
            }
        } finally {
            cn.disconnect();
        }
    }

    private void refreshCatalog() {
        if (fetching) return;
        fetching = true;
        refreshButton.setEnabled(false);
        refreshButton.setAlpha(.45f);
        setCatalogStatus("Conectando con GitHub...", MUTED);
        new Thread(() -> {
            try {
                String text = fetchText(CATALOG_URL + "?v=" + System.currentTimeMillis());
                JSONObject json = new JSONObject(text);
                if (!(json.opt("apps") instanceof JSONArray)) throw new IllegalArgumentException("apps.json no contiene la lista apps.");
                ui.post(() -> {
                    try {
                        applyCatalog(text);
                        preferences().edit().putString("catalog_cache", text).apply();
                        catalogSource = "GitHub";
                        setCatalogStatus("Catalogo: GitHub  |  Ejecucion: Android", GREEN);
                    } catch (Exception error) {
                        setCatalogStatus("No se pudo mostrar catalogo: " + error.getMessage(), RED);
                    } finally { finishRefresh(); }
                });
            } catch (Exception error) {
                ui.post(() -> {
                    setCatalogStatus("Sin conexion. Usando catalogo " + catalogSource.toLowerCase(Locale.ROOT) + ".", MUTED);
                    finishRefresh();
                });
            }
        }, "amdev-catalog-refresh").start();
    }

    private void finishRefresh() {
        fetching = false;
        refreshButton.setEnabled(true);
        refreshButton.setAlpha(1f);
    }

    private void applyCatalog(String source) throws Exception {
        JSONObject root = new JSONObject(source);
        JSONArray array = root.getJSONArray("apps");
        ArrayList<JSONObject> next = new ArrayList<>();
        for (int i = 0; i < array.length() && i < 100; i++) {
            JSONObject obj = array.optJSONObject(i);
            if (obj == null) continue;
            if (obj.has("active") || obj.has("activo")) {
                Object activeValue = obj.has("active") ? obj.opt("active") : obj.opt("activo");
                if (!Boolean.TRUE.equals(activeValue)) continue;
            }
            String id = obj.optString("id", "").trim();
            String path = obj.optString("config", "").trim();
            if (!id.matches("[a-zA-Z0-9_-]{1,60}")) continue;
            try { safeRepoPath(path); } catch (Exception invalid) { continue; }
            next.add(obj);
        }
        apps.clear();
        apps.addAll(next);
        if (findApp(selectedId) == null) selectedId = "";
        refreshCards();
    }

    private JSONObject findApp(String id) {
        for (JSONObject app : apps) if (id.equals(app.optString("id"))) return app;
        return null;
    }

    private String chosenName() {
        JSONObject item = findApp(selectedId);
        return item != null ? item.optString("name", selectedId) : "Sin seleccion";
    }

    private void updateSelection() {
        if (selectedLabel != null) selectedLabel.setText(chosenName());
        if (floatingSelection != null) floatingSelection.setText(chosenName());
    }

    private void refreshCards() {
        listContainer.removeAllViews();
        if (apps.isEmpty()) {
            TextView empty = text("No hay aplicaciones disponibles.", 14, MUTED, false);
            empty.setPadding(dp(10), dp(30), 0, dp(20));
            listContainer.addView(empty);
        }
        for (JSONObject app : apps) {
            String id = app.optString("id", "app");
            String name = app.optString("name", id);
            String description = app.optString("description", "");
            boolean selected = id.equals(selectedId);
            LinearLayout card = row();
            card.setPadding(dp(12), dp(13), dp(14), dp(13));
            card.setBackground(shape(selected ? Color.rgb(26, 67, 80) : CARD,
                    selected ? TEAL : EDGE, 12));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
            params.bottomMargin = dp(9);
            listContainer.addView(card, params);

            TextView emblem = text(id.equals("ptm") ? "P" : id.equals("pyrion") ? "OS" : id.equals("pyrion-edit") ? "3D" : "PY", 16, WHITE, true);
            emblem.setGravity(Gravity.CENTER);
            emblem.setBackground(shape(TEAL, Color.TRANSPARENT, 10));
            LinearLayout.LayoutParams emblemP = new LinearLayout.LayoutParams(dp(45), dp(45));
            emblemP.rightMargin = dp(12);
            card.addView(emblem, emblemP);

            LinearLayout words = column();
            card.addView(words, new LinearLayout.LayoutParams(0, -2, 1));
            TextView nameText = text(name, 15, WHITE, true);
            words.addView(nameText);
            TextView desc = text(description, 11, MUTED, false);
            desc.setLineSpacing(dp(2), 1f);
            LinearLayout.LayoutParams descP = new LinearLayout.LayoutParams(-1, -2);
            descP.topMargin = dp(5);
            words.addView(desc, descP);
            if (selected) {
                TextView chosen = text("SELECCIONADA", 10, GREEN, true);
                chosen.setPadding(0, dp(7), 0, 0);
                words.addView(chosen);
            }
            TextView arrow = text("\u203a", 29, RED, true);
            arrow.setPadding(dp(9), 0, 0, 0);
            card.addView(arrow);
            card.setClickable(true);
            card.setContentDescription("Abrir detalles de " + name);
            card.setOnClickListener(v -> openAppDetails(app));
        }
        updateSelection();
    }

    private void select(JSONObject app) {
        selectedId = app.optString("id", "");
        preferences().edit().putString("selected_app_id", selectedId).apply();
        refreshCards();
    }

    private void openAppDetails(JSONObject app) {
        select(app);
        final String name = app.optString("name", app.optString("id", "App"));
        final String configPath = app.optString("config", "");
        Toast.makeText(this, name + " seleccionada", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            JSONObject config = null;
            String failure = "";
            try {
                String json = fetchText(REPO_RAW + "main/" + safeRepoPath(configPath) + "?v=" + System.currentTimeMillis());
                config = new JSONObject(json);
                preferences().edit().putString("config_" + app.optString("id", ""), json).apply();
            } catch (Exception e) {
                failure = e.getMessage();
                String cached = preferences().getString("config_" + app.optString("id", ""), "");
                if (!cached.isEmpty()) {
                    try { config = new JSONObject(cached); } catch (Exception ignored) { }
                }
            }
            final JSONObject result = config;
            final String error = failure;
            ui.post(() -> { if (!isFinishing() && !isDestroyed()) showAppDetailsDialog(name, app, result, error); });
        }, "amdev-config-" + selectedId).start();
    }

    private void showAppDetailsDialog(String name, JSONObject app, JSONObject config, String fetchError) {
        LinearLayout info = column();
        info.setPadding(dp(22), dp(10), dp(22), dp(10));
        TextView title = text(name, 23, WHITE, true);
        info.addView(title);
        TextView description = text(app.optString("description", ""), 13, MUTED, false);
        description.setPadding(0, dp(9), 0, dp(11));
        info.addView(description);
        String version = config == null ? "Sin verificar" : config.optString("version", "Sin version");
        addInfoLine(info, "VERSION", version);
        addInfoLine(info, "CONFIG", app.optString("config", ""));
        String path = config == null ? "No disponible" : config.optString("app_path", "");
        addInfoLine(info, "ARCHIVO", path);
        if (config == null) addInfoLine(info, "RED", "Sin datos de configuracion. " + fetchError);
        if (config != null && config.optBoolean("maintenance", false)) addInfoLine(info, "ESTADO", "En mantenimiento");
        TextView note = text("Esta es la interfaz AMDEV para Android. Los programas Tkinter/GUI del repositorio no abren ventanas de escritorio: usa 'Abrir codigo' para ver el .py en la consola.", 12, MUTED, false);
        note.setPadding(0, dp(15), 0, dp(5));
        note.setLineSpacing(dp(3), 1f);
        info.addView(note);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(info);
        final AlertDialog dlg = new AlertDialog.Builder(this)
                .setTitle("Aplicacion AMDEV")
                .setView(scroll)
                .setPositiveButton("Abrir codigo", null)
                .setNeutralButton("Copiar URL", null)
                .setNegativeButton("Cerrar", (d, w) -> { })
                .create();
        dlg.setOnShowListener(dialog -> {
            boolean available = config != null && !config.optBoolean("maintenance", false);
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(available);
            dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setEnabled(available);
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                try {
                    String url = urlFromConfig(config);
                    dlg.dismiss();
                    openConsole(url, false);
                } catch (Exception ex) {
                    Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
            dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                try {
                    String url = urlFromConfig(config);
                    ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    clipboard.setPrimaryClip(ClipData.newPlainText("AMDEV URL", url));
                    Toast.makeText(this, "Enlace copiado", Toast.LENGTH_SHORT).show();
                } catch (Exception ex) {
                    Toast.makeText(this, ex.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
        });
        dlg.show();
    }

    private void addInfoLine(LinearLayout panel, String label, String value) {
        TextView key = text(label, 10, GREEN, true);
        key.setPadding(0, dp(9), 0, dp(1));
        panel.addView(key);
        TextView textValue = text(value, 12, WHITE, false);
        textValue.setTextIsSelectable(true);
        panel.addView(textValue);
    }

    private String urlFromConfig(JSONObject config) {
        if (config == null) throw new IllegalArgumentException("No se pudo leer config.json.");
        String path = safeRepoPath(config.optString("app_path", ""));
        String commit = config.optString("release_commit", "");
        if (!commit.matches("[0-9a-fA-F]{40}")) throw new IllegalArgumentException("La version no tiene release_commit valido.");
        return REPO_RAW + commit + "/" + path;
    }

    private void openTopMenu(View anchor) {
        PopupMenu popup = new PopupMenu(this, anchor);
        Menu m = popup.getMenu();
        m.add(0, 1, 0, "Recargar aplicaciones");
        m.add(0, 2, 1, "Consola Python 3");
        m.add(0, 3, 2, "Ver AMDEV original (.py)");
        m.add(0, 4, 3, "Informacion");
        popup.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case 1: refreshCatalog(); return true;
                case 2: openConsole(null, false); return true;
                case 3: openConsole(SELF_URL, false); return true;
                case 4: showAbout(); return true;
                default: return false;
            }
        });
        popup.show();
    }

    private void openQuickMenu() {
        List<String> options = new ArrayList<>();
        for (JSONObject item : apps) {
            String mark = item.optString("id", "").equals(selectedId) ? "\u2713  " : "     ";
            options.add(mark + item.optString("name", "App"));
        }
        int reloadIndex = options.size();
        options.add("\u21bb  Recargar catalogo");
        options.add("\u2328  Consola Python 3");
        options.add("\u24d8  Acerca de AMDEV");
        new AlertDialog.Builder(this).setTitle("AMDEV  /  Seleccionar")
                .setItems(options.toArray(new String[0]), (dialog, which) -> {
                    if (which < apps.size()) openAppDetails(apps.get(which));
                    else if (which == reloadIndex) refreshCatalog();
                    else if (which == reloadIndex + 1) openConsole(null, false);
                    else showAbout();
                }).setNegativeButton("Cerrar", null).show();
    }

    private void showAbout() {
        new AlertDialog.Builder(this)
                .setTitle("ArchMomaDEV  /  AMDEV Android")
                .setMessage("Interfaz Android basada en el lanzador AMDEV v1.0.23.\n\n"
                        + "El catalogo y la configuracion se leen del repositorio archmoba-dev. "
                        + "El interprete Python 3.11 esta integrado en la consola.\n\n"
                        + "Las ventanas Tkinter y otras GUI de escritorio requieren adaptacion individual: "
                        + "no se ejecutan como ventanas nativas por descargar su app.py.")
                .setPositiveButton("Entendido", null)
                .show();
    }

    private void openConsole(String sourceUrl, boolean autoExecute) {
        Intent intent = new Intent(this, MainActivity.class);
        if (sourceUrl != null) {
            intent.putExtra("source_url", sourceUrl);
            intent.putExtra("source_auto_run", autoExecute);
        }
        startActivity(intent);
    }
}
