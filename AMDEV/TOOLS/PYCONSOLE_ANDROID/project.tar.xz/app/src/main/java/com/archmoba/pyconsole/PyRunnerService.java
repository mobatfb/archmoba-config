package com.archmoba.pyconsole;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.Process;
import android.os.RemoteException;

import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.concurrent.CountDownLatch;

/**
 * Executes Python in an Android process separate from the user interface.
 * This allows STOP to kill code with an infinite loop immediately.
 */
public final class PyRunnerService extends Service {
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Messenger incoming = new Messenger(new Handler(Looper.getMainLooper(), this::onMessage));
    private volatile Messenger listener;
    private volatile boolean busy;
    private volatile ConsoleBridge bridge;

    @Override
    public IBinder onBind(Intent intent) {
        return incoming.getBinder();
    }

    private boolean onMessage(Message message) {
        switch (message.what) {
            case Protocol.RUN:
                listener = message.replyTo;
                if (busy) {
                    send(Protocol.STATUS, "Ya hay un script en ejecuci\u00f3n.");
                } else {
                    runAsync(message.getData().getString("path", ""));
                }
                return true;
            case Protocol.STOP:
                // This service runs under android:process=":python".
                Process.killProcess(Process.myPid());
                return true;
            case Protocol.INPUT_REPLY:
                ConsoleBridge activeBridge = bridge;
                if (activeBridge != null) {
                    Bundle data = message.getData();
                    activeBridge.provideInput(data.getBoolean("cancel", false)
                            ? null : data.getString("value", ""));
                }
                return true;
            default:
                return false;
        }
    }

    private void runAsync(String requestedPath) {
        File workspace = new File(getFilesDir(), "workspace");
        File script = new File(requestedPath);
        try {
            File canonicalWorkspace = workspace.getCanonicalFile();
            File canonicalScript = script.getCanonicalFile();
            if (!canonicalScript.getParentFile().equals(canonicalWorkspace)
                    || !canonicalScript.getName().endsWith(".py")
                    || !canonicalScript.isFile()) {
                send(Protocol.OUTPUT, "[Error] Archivo .py no v\u00e1lido.\n");
                send(Protocol.FINISHED, "1");
                return;
            }
        } catch (Exception e) {
            send(Protocol.OUTPUT, "[Error] " + e.getMessage() + "\n");
            send(Protocol.FINISHED, "1");
            return;
        }

        busy = true;
        final ConsoleBridge newBridge = new ConsoleBridge();
        bridge = newBridge;
        send(Protocol.STATUS, "Preparando Python 3...");
        Thread worker = new Thread(() -> {
            int exitStatus = 1;
            try {
                if (!Python.isStarted()) {
                    Python.start(new AndroidPlatform(getApplicationContext()));
                }
                send(Protocol.STATUS, "Ejecutando " + script.getName());
                PyObject module = Python.getInstance().getModule("py_runner");
                exitStatus = module.callAttr("execute_file", script.getAbsolutePath(),
                        getFilesDir().getAbsolutePath(), newBridge).toInt();
            } catch (Throwable error) {
                StringWriter stackTrace = new StringWriter();
                error.printStackTrace(new PrintWriter(stackTrace));
                newBridge.output("[Error del entorno]\n" + stackTrace + "\n");
            } finally {
                newBridge.flushNow();
                send(Protocol.FINISHED, Integer.toString(exitStatus));
                busy = false;
                bridge = null;
            }
        }, "pyconsole-interpreter");
        worker.setDaemon(true);
        worker.start();
    }

    private void send(int what, String text) {
        Messenger receiver = listener;
        if (receiver == null) return;
        Message message = Message.obtain(null, what);
        Bundle data = new Bundle();
        data.putString("text", text);
        message.setData(data);
        try {
            receiver.send(message);
        } catch (RemoteException ignored) {
            // UI has been closed; the OS will dispose of the bound service.
        }
    }

    /** Public methods are callable from the Python script via Chaquopy. */
    public final class ConsoleBridge {
        private final Object outputLock = new Object();
        private final StringBuilder pending = new StringBuilder();
        private static final int OUTPUT_LIMIT = 150000;
        private int printed = 0;
        private boolean queued = false;
        private final Object inputLock = new Object();
        private CountDownLatch inputLatch;
        private String inputValue;

        public void output(String text) {
            if (text == null || text.isEmpty()) return;
            synchronized (outputLock) {
                if (printed >= OUTPUT_LIMIT) return;
                int remaining = OUTPUT_LIMIT - printed;
                if (text.length() > remaining) {
                    pending.append(text, 0, remaining);
                    pending.append("\n[Salida truncada para proteger la consola]\n");
                    printed = OUTPUT_LIMIT;
                } else {
                    pending.append(text);
                    printed += text.length();
                }
                if (!queued) {
                    queued = true;
                    mainHandler.postDelayed(this::flushNow, 80);
                }
            }
        }

        public void flushNow() {
            String result;
            synchronized (outputLock) {
                result = pending.toString();
                pending.setLength(0);
                queued = false;
            }
            for (int start = 0; start < result.length(); start += 3000) {
                send(Protocol.OUTPUT, result.substring(start, Math.min(start + 3000, result.length())));
            }
        }

        public String requestInput() {
            flushNow();
            CountDownLatch waiting = new CountDownLatch(1);
            synchronized (inputLock) {
                inputLatch = waiting;
                inputValue = null;
            }
            send(Protocol.INPUT_REQUEST, "");
            try {
                waiting.await();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return null;
            }
            synchronized (inputLock) {
                String answer = inputValue;
                inputLatch = null;
                inputValue = null;
                return answer;
            }
        }

        private void provideInput(String value) {
            synchronized (inputLock) {
                if (inputLatch != null) {
                    inputValue = value;
                    inputLatch.countDown();
                }
            }
        }
    }
}
