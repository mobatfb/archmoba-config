package com.archmoba.pyconsole;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Android adaptation of the PTM 1.0.79 home/search/catalog interface.
 *  This does not attempt to instantiate desktop Tkinter widgets.
 */
public final class PTMActivity extends Activity {
    private static final String GUIDE_URL = "https://raw.githubusercontent.com/mobatfb/archmoba-dev/main/PTM/guide.csv";
    private static final String ROOT = "https://raw.githubusercontent.com/mobatfb/archmoba-dev/main/PTM/";
    private static final String[] MODES = {"Todas", "Recientes", "Favoritos", "Mas usados", "Recomendados"};
    private static final int BG = Color.rgb(247, 249, 251);
    private static final int WHITE = Color.WHITE;
    private static final int INK = Color.rgb(17, 33, 47);
    private static final int SOFT = Color.rgb(86, 102, 115);
    private static final int TEAL = Color.rgb(23, 102, 132);
    private static final int TEAL_TINT = Color.rgb(227, 242, 248);
    private static final int EDGE = Color.rgb(211, 225, 234);
    private static final int RED = Color.rgb(230, 58, 58);
    private static final int MAX_GUIDE_BYTES = 350 * 1024;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ArrayList<Tool> tools = new ArrayList<>();
    private final ArrayList<Tool> openTabs = new ArrayList<>();
    private TextView sourceLabel;
    private TextView resultCount;
    private TextView modeLabel;
    private LinearLayout resultList;
    private LinearLayout tabsRow;
    private LinearLayout searchPage;
    private LinearLayout toolPage;
    private LinearLayout categoriesRow;
    private Button refreshButton;
    private EditText searchInput;
    private String currentMode = "Todas";
    private String currentCategory = "Todas";
    private String activeTool = "";
    private String catalogSource = "Incluido";
    private boolean syncing = false;
    private boolean showAll = false;
    private SharedPreferences prefs;

    private static final class Tool {
        String id, slug, title, description, keywords, category, version, mode, fileType, repoPath, entry, dependencies;
        int visits;
        String url() {
            if (repoPath == null || !repoPath.matches("[A-Za-z0-9._/-]{1,200}") || repoPath.contains("..")) {
                throw new IllegalArgumentException("Ruta de herramienta no permitida.");
            }
            StringBuilder url = new StringBuilder(ROOT);
            String[] segments = repoPath.split("/");
            for (int i = 0; i < segments.length; i++) {
                if (i > 0) url.append('/');
                url.append(android.net.Uri.encode(segments[i]));
            }
            return url.toString();
        }
    }

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        prefs = getSharedPreferences("ptm_android", MODE_PRIVATE);
        getWindow().setStatusBarColor(TEAL);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        buildUi();
        loadCached();
        updateTabs();
        applySearch();
        refreshGuide();
    }

    private int dp(float px) { return Math.round(px * getResources().getDisplayMetrics().density); }
    private GradientDrawable shape(int color, int stroke, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        if (stroke != Color.TRANSPARENT) g.setStroke(dp(1), stroke);
        return g;
    }
    private TextView label(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }
    private LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }
    private Button button(String title, boolean primary) {
        Button b = new Button(this);
        b.setText(title);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setTextColor(primary ? WHITE : TEAL);
        b.setBackground(shape(primary ? TEAL : WHITE, primary ? Color.TRANSPARENT : EDGE, 10));
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(12), 0, dp(12), 0);
        return b;
    }

    private void buildUi() {
        LinearLayout root = column();
        root.setBackgroundColor(BG);
        setContentView(root);

        LinearLayout header = row();
        header.setPadding(dp(14), dp(9), dp(14), dp(8));
        header.setBackgroundColor(WHITE);
        root.addView(header, new LinearLayout.LayoutParams(-1, dp(67)));
        Button amdev = button("AMDEV", false);
        header.addView(amdev, new LinearLayout.LayoutParams(dp(80), dp(42)));
        amdev.setOnClickListener(v -> openAmdev());
        LinearLayout brand = column();
        brand.setPadding(dp(14), 0, dp(5), 0);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        brand.addView(label("PTM", 22, TEAL, true));
        brand.addView(label("BUSCADOR DE HERRAMIENTAS", 9, SOFT, true));
        Button console = button("Python 3", true);
        header.addView(console, new LinearLayout.LayoutParams(dp(99), dp(42)));
        console.setOnClickListener(v -> openConsole(null, false));

        HorizontalScrollView tabScroller = new HorizontalScrollView(this);
        tabScroller.setHorizontalScrollBarEnabled(false);
        tabScroller.setBackgroundColor(WHITE);
        root.addView(tabScroller, new LinearLayout.LayoutParams(-1, dp(47)));
        tabsRow = row();
        tabsRow.setPadding(dp(13), dp(1), dp(12), dp(6));
        tabScroller.addView(tabsRow);

        ScrollView scroller = new ScrollView(this);
        scroller.setFillViewport(true);
        root.addView(scroller, new LinearLayout.LayoutParams(-1, 0, 1));
        FrameLayout frame = new FrameLayout(this);
        scroller.addView(frame, new ScrollView.LayoutParams(-1, -2));
        searchPage = column();
        searchPage.setPadding(dp(16), dp(19), dp(16), dp(18));
        frame.addView(searchPage);
        toolPage = column();
        toolPage.setPadding(dp(16), dp(19), dp(16), dp(20));
        toolPage.setVisibility(View.GONE);
        frame.addView(toolPage);

        TextView heading = label("Encuentra tus herramientas", 23, INK, true);
        searchPage.addView(heading);
        TextView sub = label("Catálogo de PTM sincronizado con GitHub", 12, SOFT, false);
        sub.setPadding(0, dp(4), 0, dp(15));
        searchPage.addView(sub);

        LinearLayout bar = row();
        bar.setPadding(dp(8), dp(3), dp(5), dp(3));
        bar.setBackground(shape(WHITE, EDGE, 12));
        searchPage.addView(bar, new LinearLayout.LayoutParams(-1, dp(55)));
        searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setTextSize(15);
        searchInput.setTextColor(INK);
        searchInput.setHintTextColor(SOFT);
        searchInput.setBackgroundColor(Color.TRANSPARENT);
        searchInput.setHint("Buscar herramienta o comando...");
        searchInput.setFilters(new InputFilter[] {new InputFilter.LengthFilter(40)});
        searchInput.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        bar.addView(searchInput, new LinearLayout.LayoutParams(0, -1, 1));
        Button clear = button("X", false);
        bar.addView(clear, new LinearLayout.LayoutParams(dp(40), dp(38)));
        clear.setOnClickListener(v -> { searchInput.setText(""); searchInput.requestFocus(); });
        searchInput.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH || (event != null && event.getKeyCode() == android.view.KeyEvent.KEYCODE_ENTER)) {
                showAll = true;
                applySearch();
                InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (imm != null) imm.hideSoftInputFromWindow(searchInput.getWindowToken(), 0);
                searchInput.clearFocus();
                return true;
            }
            return false;
        });
        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                String command = s.toString().toLowerCase(Locale.ROOT).trim();
                if (command.equals("%recents%")) { setMode("Recientes"); return; }
                if (command.equals("%favorites%")) { setMode("Favoritos"); return; }
                if (command.equals("%used%") || command.equals("%mostused%")) { setMode("Mas usados"); return; }
                if (command.equals("%recommended%")) { setMode("Recomendados"); return; }
                showAll = false;
                applySearch();
            }
            @Override public void afterTextChanged(Editable s) { }
        });

        HorizontalScrollView modesScroll = new HorizontalScrollView(this);
        modesScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout.LayoutParams modeP = new LinearLayout.LayoutParams(-1, dp(55));
        modeP.topMargin = dp(8);
        searchPage.addView(modesScroll, modeP);
        LinearLayout modes = row();
        modesScroll.addView(modes);
        for (String mode : MODES) {
            Button b = button(mode, false);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, dp(38));
            p.rightMargin = dp(6);
            modes.addView(b, p);
            b.setOnClickListener(v -> setMode(mode));
        }

        LinearLayout sourcePanel = row();
        sourcePanel.setBackground(shape(TEAL_TINT, EDGE, 12));
        sourcePanel.setPadding(dp(12), dp(9), dp(6), dp(9));
        searchPage.addView(sourcePanel, new LinearLayout.LayoutParams(-1, dp(56)));
        sourceLabel = label("Catálogo integrado / conectando...", 11, TEAL, true);
        sourcePanel.addView(sourceLabel, new LinearLayout.LayoutParams(0, -2, 1));
        refreshButton = button("Actualizar", false);
        sourcePanel.addView(refreshButton, new LinearLayout.LayoutParams(dp(98), dp(38)));
        refreshButton.setOnClickListener(v -> refreshGuide());

        TextView categoryHeading = label("CATEGORIAS", 11, SOFT, true);
        categoryHeading.setPadding(dp(2), dp(19), 0, dp(8));
        searchPage.addView(categoryHeading);
        HorizontalScrollView catScroll = new HorizontalScrollView(this);
        catScroll.setHorizontalScrollBarEnabled(false);
        searchPage.addView(catScroll, new LinearLayout.LayoutParams(-1, dp(47)));
        categoriesRow = row();
        catScroll.addView(categoriesRow);

        LinearLayout countRow = row();
        countRow.setPadding(0, dp(14), 0, dp(9));
        searchPage.addView(countRow);
        modeLabel = label("HERRAMIENTAS", 13, INK, true);
        countRow.addView(modeLabel, new LinearLayout.LayoutParams(0, -2, 1));
        resultCount = label("", 12, SOFT, false);
        countRow.addView(resultCount);
        resultList = column();
        searchPage.addView(resultList);

        LinearLayout footer = row();
        footer.setPadding(dp(15), dp(8), dp(15), dp(8));
        footer.setBackgroundColor(WHITE);
        root.addView(footer, new LinearLayout.LayoutParams(-1, dp(54)));
        TextView version = label("PTM v1.0.79  /  Android 0.4", 11, SOFT, false);
        footer.addView(version, new LinearLayout.LayoutParams(0, -2, 1));
        Button refreshBottom = button("Recargar", false);
        footer.addView(refreshBottom, new LinearLayout.LayoutParams(dp(91), dp(37)));
        refreshBottom.setOnClickListener(v -> refreshGuide());
    }

    private void openAmdev() {
        Intent intent = new Intent(this, AMDEVActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(intent);
        finish();
    }
    private void openConsole(String url, boolean autoRun) {
        Intent intent = new Intent(this, MainActivity.class);
        if (url != null) {
            intent.putExtra("source_url", url);
            intent.putExtra("source_auto_run", autoRun);
        }
        startActivity(intent);
    }

    private void loadCached() {
        String data = prefs.getString("guide_cache", "");
        if (!data.isEmpty()) catalogSource = "Cache";
        else {
            catalogSource = "Incluido";
            try (InputStream in = getAssets().open("ptm_guide.csv")) {
                data = new String(readLimited(in), StandardCharsets.UTF_8);
            } catch (Exception e) { data = ""; }
        }
        try { parseGuide(data); } catch (Exception ignored) { tools.clear(); }
        updateCategories();
        setSource("Catálogo: " + catalogSource + "  ·  sincronizando...", SOFT);
    }

    private static byte[] readLimited(InputStream stream) throws Exception {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buff = new byte[8192];
        int n;
        while ((n = stream.read(buff)) != -1) {
            if (output.size() + n > MAX_GUIDE_BYTES) throw new IllegalArgumentException("Catálogo demasiado grande.");
            output.write(buff, 0, n);
        }
        return output.toByteArray();
    }
    private void setSource(String value, int color) {
        sourceLabel.setText(value);
        sourceLabel.setTextColor(color);
    }
    private void refreshGuide() {
        if (syncing) return;
        syncing = true;
        refreshButton.setEnabled(false);
        setSource("Conectando con GitHub...", TEAL);
        new Thread(() -> {
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(GUIDE_URL + "?ts=" + System.currentTimeMillis()).openConnection();
                conn.setConnectTimeout(12000);
                conn.setReadTimeout(19000);
                conn.setInstanceFollowRedirects(false);
                conn.setRequestProperty("User-Agent", "PTM-Android/0.4");
                byte[] bytes;
                try {
                    if (conn.getResponseCode() != 200) throw new IllegalArgumentException("GitHub respondió HTTP " + conn.getResponseCode());
                    try (InputStream in = conn.getInputStream()) { bytes = readLimited(in); }
                } finally { conn.disconnect(); }
                String text = new String(bytes, StandardCharsets.UTF_8);
                ArrayList<Tool> parsed = readRows(text);
                if (parsed.isEmpty()) throw new IllegalArgumentException("No se encontraron herramientas válidas.");
                ui.post(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    tools.clear(); tools.addAll(parsed);
                    prefs.edit().putString("guide_cache", text).apply();
                    catalogSource = "GitHub";
                    setSource("Catálogo GitHub  ·  " + tools.size() + " herramientas", TEAL);
                    updateCategories(); applySearch(); renderCurrentTool();
                    syncing = false; refreshButton.setEnabled(true);
                });
            } catch (Exception e) {
                ui.post(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    setSource("Sin conexión · catálogo " + catalogSource, SOFT);
                    syncing = false; refreshButton.setEnabled(true);
                });
            }
        }, "ptm-guide-fetch").start();
    }
    private void parseGuide(String raw) {
        ArrayList<Tool> parsed = readRows(raw);
        if (parsed.isEmpty()) throw new IllegalArgumentException("Catálogo vacío");
        tools.clear(); tools.addAll(parsed);
    }
    private static ArrayList<Tool> readRows(String raw) {
        ArrayList<Tool> found = new ArrayList<>();
        String[] lines = raw.replace("\r", "").replace("\ufeff", "").split("\n");
        for (int i = 1; i < lines.length && found.size() < 2000; i++) {
            String[] fields = splitSemicolon(lines[i]);
            if (fields.length < 16) continue;
            // PTM's guide.csv has a few legacy unquoted semicolons in descriptions.
            // Recover by anchoring the trailing 12 columns instead of shifting fields.
            if (fields.length > 16) {
                String[] merged = new String[16];
                System.arraycopy(fields, 0, merged, 0, 3);
                StringBuilder desc = new StringBuilder();
                for (int j = 3; j < fields.length - 12; j++) {
                    if (j > 3) desc.append("; ");
                    desc.append(fields[j]);
                }
                merged[3] = desc.toString();
                System.arraycopy(fields, fields.length - 12, merged, 4, 12);
                fields = merged;
            }
            try {
                Tool t = new Tool();
                t.id = fields[0].trim(); t.slug = fields[1].trim(); t.title = fields[2].trim();
                t.description = fields[3].trim(); t.keywords = fields[4].trim(); t.category = fields[5].trim();
                t.version = fields[6].trim(); t.mode = fields[7].trim(); t.fileType = fields[8].trim().toLowerCase(Locale.ROOT);
                t.repoPath = fields[9].trim(); t.entry = fields[10].trim(); t.dependencies = fields[11].trim();
                t.visits = Integer.parseInt(fields[14].trim());
                if (!(fields[12].trim().equals("1") || fields[12].trim().equalsIgnoreCase("true"))) continue;
                if (!t.slug.matches("[A-Za-z0-9_-]{1,100}") || t.title.isEmpty()) continue;
                if (!t.fileType.equals("py") && !t.fileType.equals("zip")) continue;
                if (t.repoPath.contains("..") || !t.repoPath.matches("[A-Za-z0-9._/-]{1,200}")) continue;
                found.add(t);
            } catch (Exception ignored) { }
        }
        return found;
    }
    private static String[] splitSemicolon(String row) {
        ArrayList<String> cols = new ArrayList<>();
        StringBuilder cell = new StringBuilder();
        boolean quoted = false;
        for (int i = 0; i < row.length(); i++) {
            char ch = row.charAt(i);
            if (ch == '"') {
                if (quoted && i + 1 < row.length() && row.charAt(i + 1) == '"') { cell.append('"'); i++; }
                else quoted = !quoted;
            } else if (ch == ';' && !quoted) { cols.add(cell.toString()); cell.setLength(0); }
            else cell.append(ch);
        }
        cols.add(cell.toString());
        return cols.toArray(new String[0]);
    }

    private Set<String> favorites() { return new HashSet<>(prefs.getStringSet("favorites", new HashSet<>())); }
    private boolean isFavorite(Tool t) { return favorites().contains(t.slug); }
    private void toggleFavorite(Tool t) {
        Set<String> favorite = favorites();
        if (!favorite.add(t.slug)) favorite.remove(t.slug);
        prefs.edit().putStringSet("favorites", favorite).apply();
        applySearch(); renderCurrentTool(); updateTabs();
    }
    private int usage(Tool t) { return prefs.getInt("uses_" + t.slug, 0); }
    private void recordOpen(Tool t) {
        prefs.edit().putInt("uses_" + t.slug, usage(t) + 1).apply();
        String old = prefs.getString("recent", "");
        ArrayList<String> ordered = new ArrayList<>();
        ordered.add(t.slug);
        for (String s : old.split(",")) if (!s.isEmpty() && !ordered.contains(s) && ordered.size() < 50) ordered.add(s);
        prefs.edit().putString("recent", TextUtils.join(",", ordered)).apply();
    }
    private int recency(Tool t) {
        String[] recent = prefs.getString("recent", "").split(",");
        for (int i = 0; i < recent.length; i++) if (recent[i].equals(t.slug)) return i;
        return 999999;
    }
    private static String normalize(String x) {
        return Normalizer.normalize(x == null ? "" : x, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "").toLowerCase(Locale.ROOT);
    }
    private void setMode(String mode) {
        currentMode = mode;
        if (!searchInput.getText().toString().trim().isEmpty() && searchInput.getText().toString().startsWith("%")) {
            searchInput.setText("");
        }
        showAll = false; applySearch();
    }
    private void updateCategories() {
        if (categoriesRow == null) return;
        categoriesRow.removeAllViews();
        Set<String> keys = new HashSet<>();
        for (Tool t : tools) if (!t.category.isEmpty()) keys.add(t.category);
        ArrayList<String> categories = new ArrayList<>(keys);
        Collections.sort(categories);
        categories.add(0, "Todas");
        for (String c : categories) {
            boolean active = c.equals(currentCategory);
            Button b = button(c, active);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-2, dp(34));
            params.rightMargin = dp(6);
            categoriesRow.addView(b, params);
            b.setOnClickListener(v -> { currentCategory = c; applySearch(); });
        }
    }
    private ArrayList<Tool> filtered() {
        ArrayList<Tool> result = new ArrayList<>();
        String q = normalize(searchInput.getText().toString().trim());
        Set<String> liked = favorites();
        String[] tokens = q.isEmpty() ? new String[0] : q.split("\\s+");
        for (Tool t : tools) {
            if (!currentCategory.equals("Todas") && !t.category.equals(currentCategory)) continue;
            if (currentMode.equals("Favoritos") && !liked.contains(t.slug)) continue;
            if (currentMode.equals("Recientes") && recency(t) == 999999) continue;
            if (currentMode.equals("Mas usados") && usage(t) == 0) continue;
            boolean match = true;
            String all = normalize(t.title + " " + t.description + " " + t.keywords + " " + t.category + " " + t.slug);
            for (String token : tokens) if (!all.contains(token)) { match = false; break; }
            if (match) result.add(t);
        }
        Comparator<Tool> order;
        if (currentMode.equals("Recientes")) order = Comparator.comparingInt(this::recency);
        else if (currentMode.equals("Mas usados")) order = Comparator.comparingInt((Tool t) -> usage(t)).reversed();
        else if (currentMode.equals("Recomendados")) order = Comparator.comparingInt((Tool t) -> t.visits).reversed();
        else if (!q.isEmpty()) order = Comparator.comparingInt((Tool t) -> score(t, q)).reversed();
        else order = Comparator.comparing((Tool t) -> normalize(t.title));
        result.sort(order);
        return result;
    }
    private int score(Tool t, String query) {
        String title = normalize(t.title), slug = normalize(t.slug), kw = normalize(t.keywords);
        int points = 0;
        if (title.equals(query)) points += 300;
        if (title.startsWith(query)) points += 120;
        if (title.contains(query)) points += 60;
        if (slug.contains(query)) points += 35;
        if (kw.contains(query)) points += 20;
        if (isFavorite(t)) points += 10;
        return points + Math.min(t.visits / 50, 15);
    }

    private void applySearch() {
        if (resultList == null || searchInput == null) return;
        if (!activeTool.isEmpty()) return; // Preserve the open tab.
        resultList.removeAllViews();
        modeLabel.setText("HERRAMIENTAS / " + currentMode.toUpperCase(Locale.ROOT));
        ArrayList<Tool> found = filtered();
        resultCount.setText(found.size() + " encontradas");
        if (found.isEmpty()) {
            TextView empty = label(currentMode.equals("Favoritos") ?
                    "No tienes favoritos todavía. Abre una herramienta y toca la estrella." :
                    "No se encontraron herramientas. Prueba otra búsqueda o actualiza el catálogo.", 14, SOFT, false);
            empty.setPadding(dp(16), dp(24), dp(16), dp(24));
            resultList.addView(empty);
            return;
        }
        int max = showAll || !searchInput.getText().toString().trim().isEmpty() ? 80 : 15;
        for (int i = 0; i < Math.min(found.size(), max); i++) {
            Tool t = found.get(i);
            LinearLayout card = row();
            card.setPadding(dp(13), dp(13), dp(11), dp(13));
            card.setBackground(shape(WHITE, EDGE, 12));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
            p.bottomMargin = dp(9);
            resultList.addView(card, p);
            TextView icon = label(t.title.isEmpty() ? "?" : t.title.substring(0, 1).toUpperCase(Locale.ROOT), 19, TEAL, true);
            icon.setGravity(Gravity.CENTER);
            icon.setBackground(shape(TEAL_TINT, Color.TRANSPARENT, 10));
            LinearLayout.LayoutParams iconP = new LinearLayout.LayoutParams(dp(45), dp(45));
            iconP.rightMargin = dp(13);
            card.addView(icon, iconP);
            LinearLayout column = column();
            card.addView(column, new LinearLayout.LayoutParams(0, -2, 1));
            TextView name = label(t.title, 14, INK, true);
            column.addView(name);
            TextView meta = label(t.category + "  ·  v" + t.version + (isFavorite(t) ? "  ·  ★" : ""), 10, TEAL, true);
            meta.setPadding(0, dp(2), 0, dp(3));
            column.addView(meta);
            TextView desc = label(t.description, 11, SOFT, false);
            desc.setMaxLines(2);
            desc.setEllipsize(TextUtils.TruncateAt.END);
            column.addView(desc);
            TextView arrow = label("›", 27, RED, true);
            arrow.setPadding(dp(8), 0, 0, 0);
            card.addView(arrow);
            card.setOnClickListener(v -> openTool(t));
        }
        if (found.size() > max) {
            Button more = button("Ver más resultados", false);
            resultList.addView(more, new LinearLayout.LayoutParams(-1, dp(47)));
            more.setOnClickListener(v -> { showAll = true; applySearch(); });
        }
    }

    private Tool lookup(String slug) {
        for (Tool t : tools) if (t.slug.equals(slug)) return t;
        return null;
    }
    private void updateTabs() {
        if (tabsRow == null) return;
        tabsRow.removeAllViews();
        TextView home = label("PTM / Inicio", 13, activeTool.isEmpty() ? WHITE : TEAL, true);
        home.setPadding(dp(15), 0, dp(15), 0);
        home.setGravity(Gravity.CENTER);
        home.setBackground(shape(activeTool.isEmpty() ? TEAL : TEAL_TINT, Color.TRANSPARENT, 9));
        tabsRow.addView(home, new LinearLayout.LayoutParams(-2, dp(37)));
        home.setOnClickListener(v -> showHome());
        for (Tool t : new ArrayList<>(openTabs)) {
            LinearLayout tab = row();
            tab.setBackground(shape(activeTool.equals(t.slug) ? TEAL : TEAL_TINT, Color.TRANSPARENT, 9));
            LinearLayout.LayoutParams outer = new LinearLayout.LayoutParams(-2, dp(37));
            outer.leftMargin = dp(7);
            tabsRow.addView(tab, outer);
            TextView name = label(t.title, 12, activeTool.equals(t.slug) ? WHITE : TEAL, true);
            name.setMaxWidth(dp(140));
            name.setEllipsize(TextUtils.TruncateAt.END);
            name.setSingleLine(true);
            name.setPadding(dp(12), 0, dp(4), 0);
            tab.addView(name);
            name.setOnClickListener(v -> showTool(t));
            TextView close = label("×", 17, activeTool.equals(t.slug) ? WHITE : RED, true);
            close.setPadding(dp(7), 0, dp(11), 0);
            tab.addView(close);
            close.setOnClickListener(v -> closeTab(t));
        }
    }
    private void openTool(Tool t) {
        recordOpen(t);
        boolean found = false;
        for (Tool entry : openTabs) if (entry.slug.equals(t.slug)) { found = true; break; }
        if (!found) openTabs.add(t);
        showTool(t);
    }
    private void showHome() {
        activeTool = "";
        toolPage.setVisibility(View.GONE);
        searchPage.setVisibility(View.VISIBLE);
        updateTabs(); applySearch();
    }
    private void showTool(Tool t) {
        activeTool = t.slug;
        searchPage.setVisibility(View.GONE);
        toolPage.setVisibility(View.VISIBLE);
        updateTabs(); renderCurrentTool();
    }
    private void closeTab(Tool t) {
        openTabs.removeIf(entry -> entry.slug.equals(t.slug));
        if (activeTool.equals(t.slug)) showHome();
        else updateTabs();
    }
    private void renderCurrentTool() {
        if (activeTool.isEmpty() || toolPage == null) return;
        Tool t = lookup(activeTool);
        if (t == null) {
            for (Tool open : openTabs) if (open.slug.equals(activeTool)) { t = open; break; }
        }
        if (t == null) { showHome(); return; }
        toolPage.removeAllViews();
        Button back = button("‹  Volver al buscador", false);
        toolPage.addView(back, new LinearLayout.LayoutParams(-1, dp(44)));
        back.setOnClickListener(v -> showHome());
        TextView category = label(t.category.toUpperCase(Locale.ROOT), 12, TEAL, true);
        category.setPadding(0, dp(22), 0, dp(8));
        toolPage.addView(category);
        TextView title = label(t.title, 25, INK, true);
        toolPage.addView(title);
        TextView version = label("Versión " + t.version + "  ·  " + t.mode + "  ·  " + t.fileType.toUpperCase(Locale.ROOT), 12, SOFT, false);
        version.setPadding(0, dp(9), 0, dp(14));
        toolPage.addView(version);
        LinearLayout card = column();
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackground(shape(WHITE, EDGE, 12));
        toolPage.addView(card);
        TextView description = label(t.description, 14, INK, false);
        description.setLineSpacing(dp(4), 1f);
        card.addView(description);
        addInfo(card, "Ruta", "PTM/" + t.repoPath);
        addInfo(card, "Archivo principal", t.entry);
        addInfo(card, "Dependencias", t.dependencies.isEmpty() ? "Python estándar" : t.dependencies);
        addInfo(card, "Palabras clave", t.keywords);

        LinearLayout controls = row();
        controls.setPadding(0, dp(14), 0, dp(9));
        toolPage.addView(controls);
        Button fav = button(isFavorite(t) ? "★ Favorito" : "☆ Favorito", false);
        controls.addView(fav, new LinearLayout.LayoutParams(0, dp(46), 1));
        Tool selected = t;
        fav.setOnClickListener(v -> toggleFavorite(selected));
        Button copy = button("Copiar URL", false);
        LinearLayout.LayoutParams copyP = new LinearLayout.LayoutParams(0, dp(46), 1);
        copyP.leftMargin = dp(8);
        controls.addView(copy, copyP);
        copy.setOnClickListener(v -> copyUrl(selected));

        Button openSource = button(t.fileType.equals("py") ? "Abrir código en Python 3" : "Abrir paquete ZIP", true);
        LinearLayout.LayoutParams runP = new LinearLayout.LayoutParams(-1, dp(50));
        runP.topMargin = dp(4);
        toolPage.addView(openSource, runP);
        openSource.setOnClickListener(v -> openToolSource(selected, false));
        if (t.fileType.equals("py")) {
            Button run = button("Intentar ejecutar (solo scripts sin GUI de escritorio)", false);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(49));
            p.topMargin = dp(9);
            toolPage.addView(run, p);
            run.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setTitle("Compatibilidad Android")
                    .setMessage("Los scripts que usan Tkinter, PyQt o motores gráficos de escritorio no pueden mostrar su interfaz en Android. Solo se ejecutarán scripts compatibles con el motor Python incluido.")
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Continuar", (d, which) -> openToolSource(selected, true)).show());
        }
        TextView note = label("Esta pantalla PTM ya es nativa en Android. Cada herramienta de escritorio necesita su propia adaptación gráfica; abrir el código no convierte automáticamente sus ventanas a Android.", 12, SOFT, false);
        note.setPadding(dp(4), dp(17), dp(4), dp(4));
        note.setLineSpacing(dp(3), 1f);
        toolPage.addView(note);
    }
    private void addInfo(LinearLayout panel, String title, String value) {
        TextView key = label(title.toUpperCase(Locale.ROOT), 10, TEAL, true);
        key.setPadding(0, dp(13), 0, dp(3));
        panel.addView(key);
        TextView line = label(value, 12, SOFT, false);
        line.setTextIsSelectable(true);
        panel.addView(line);
    }
    private void copyUrl(Tool t) {
        try {
            String url = t.url();
            ClipboardManager clip = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (clip != null) clip.setPrimaryClip(ClipData.newPlainText("PTM script", url));
            Toast.makeText(this, "Enlace copiado", Toast.LENGTH_SHORT).show();
        } catch (Exception error) { Toast.makeText(this, error.getMessage(), Toast.LENGTH_LONG).show(); }
    }
    private void openToolSource(Tool t, boolean execute) {
        try {
            if (t.fileType.equals("zip")) {
                new AlertDialog.Builder(this).setTitle("Herramienta ZIP")
                        .setMessage("Este paquete incluye varios archivos y no puede ejecutarse como un único script .py. Copia el enlace para descargarlo o adáptalo para Android.")
                        .setPositiveButton("Copiar enlace", (d, w) -> copyUrl(t))
                        .setNegativeButton("Cerrar", null).show();
                return;
            }
            openConsole(t.url(), execute);
        } catch (Exception error) { Toast.makeText(this, error.getMessage(), Toast.LENGTH_LONG).show(); }
    }
    @Override public void onBackPressed() {
        if (!activeTool.isEmpty()) showHome();
        else super.onBackPressed();
    }
}
