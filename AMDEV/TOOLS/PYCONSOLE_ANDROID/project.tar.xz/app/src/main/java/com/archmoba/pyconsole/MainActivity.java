package com.archmoba.pyconsole;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.provider.OpenableColumns;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Comparator;

public final class MainActivity extends Activity {
    private static final int REQUEST_IMPORT = 201;
    private static final int REQUEST_EXPORT = 202;
    private static final int BG = Color.rgb(6, 17, 29);
    private static final int PANEL = Color.rgb(13, 34, 50);
    private static final int BORDER = Color.rgb(34, 75, 98);
    private static final int ACCENT = Color.rgb(67, 217, 255);
    private static final int WHITE = Color.rgb(226, 245, 255);
    private static final int MUTED = Color.rgb(139, 167, 186);
    private static final int GREEN = Color.rgb(104, 227, 165);
    private static final int RED = Color.rgb(250, 110, 124);
    private static final int MAX_SCRIPT_BYTES = 1024 * 1024;
    private static final int MAX_CONSOLE_CHARS = 95000;

    private String selectedName = "ejemplo.py";
    private EditText editor;
    private TextView console;
    private TextView status;
    private TextView filename;
    private ScrollView outputScroll;
    private Button playButton;
    private Button stopButton;
    private boolean running = false;
    private boolean stopping = false;
    private boolean bound = false;
    private boolean startWhenConnected = false;
    private Messenger service;
    private AlertDialog inputDialog;
    private final Messenger incoming = new Messenger(new Handler(Looper.getMainLooper(), this::handleMessage));

    private static final String EXAMPLE =
            "import sys\n\n"
            + "print('Hola desde AMDEV PyConsole')\n"
            + "print('Python:', sys.version.split()[0])\n\n"
            + "nombre = input('\u00bfC\u00f3mo te llamas? ')\n"
            + "print(f'Bienvenido, {nombre}!')\n";

    private final ServiceConnection connection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            service = new Messenger(binder);
            bound = true;
            if (startWhenConnected) {
                startWhenConnected = false;
                sendRun();
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            bound = false;
            service = null;
            if (inputDialog != null) {
                inputDialog.dismiss();
                inputDialog = null;
            }
            if (running) {
                running = false;
                appendConsole(stopping ? "\n[Proceso detenido]\n" : "\n[Proceso finalizado inesperadamente]\n");
                setStatus(stopping ? "Detenido" : "Int\u00e9rprete desconectado", stopping ? MUTED : RED);
            }
            stopping = false;
            updateButtons();
        }
    };

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        renderUi();
        File last = new File(getWorkspace(), getPreferences(MODE_PRIVATE).getString("last", ""));
        if (last.isFile() && last.getName().endsWith(".py")) {
            try {
                loadLocal(last);
            } catch (Exception error) {
                editor.setText(EXAMPLE);
            }
        } else {
            editor.setText(EXAMPLE);
        }
        console.setText("PyConsole listo. Pulsa Ejecutar para iniciar Python 3.\n");
        updateButtons();
    }

    private boolean handleMessage(Message message) {
        String text = message.getData().getString("text", "");
        switch (message.what) {
            case Protocol.OUTPUT:
                appendConsole(text);
                return true;
            case Protocol.STATUS:
                setStatus(text, ACCENT);
                return true;
            case Protocol.FINISHED:
                running = false;
                stopping = false;
                if ("0".equals(text)) {
                    setStatus("Finalizado correctamente", GREEN);
                    appendConsole("\n[Proceso terminado: OK]\n");
                } else {
                    setStatus("Finalizado con errores", RED);
                    appendConsole("\n[Proceso terminado: ERROR]\n");
                }
                updateButtons();
                return true;
            case Protocol.INPUT_REQUEST:
                showInputPrompt();
                return true;
            default:
                return false;
        }
    }

    private void renderUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(12), dp(14), dp(10));
        root.setBackgroundColor(BG);
        setContentView(root);

        TextView brand = label("AMDEV  /  PYCONSOLE", 20, ACCENT, true);
        brand.setLetterSpacing(0.07f);
        root.addView(brand);
        TextView subtitle = label("Python 3 integrado  |  scripts .py  |  Android", 11, MUTED, false);
        subtitle.setPadding(0, dp(2), 0, dp(11));
        root.addView(subtitle);

        LinearLayout stateRow = new LinearLayout(this);
        stateRow.setGravity(Gravity.CENTER_VERTICAL);
        filename = label(selectedName, 12, WHITE, true);
        filename.setSingleLine(true);
        filename.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        stateRow.addView(filename, new LinearLayout.LayoutParams(0, dp(30), 1f));
        status = label("Listo", 11, GREEN, true);
        status.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        stateRow.addView(status);
        root.addView(stateRow);

        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        tools.setPadding(0, dp(7), 0, dp(5));
        root.addView(tools);
        addButton(tools, "Nuevo", PANEL, this::newScript);
        addButton(tools, "Abrir .py", PANEL, this::openDocument);
        addButton(tools, "Biblioteca", PANEL, this::showLibrary);

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setPadding(0, 0, 0, dp(7));
        root.addView(actions);
        addButton(actions, "Guardar", PANEL, this::saveScript);
        addButton(actions, "Exportar", PANEL, this::exportDocument);
        playButton = addButton(actions, "Ejecutar", Color.rgb(0, 105, 139), this::execute);
        stopButton = addButton(actions, "Detener", Color.rgb(92, 36, 52), this::stopRunning);

        TextView codeLabel = label("EDITOR  /  PYTHON", 11, MUTED, true);
        codeLabel.setPadding(dp(3), dp(5), 0, dp(6));
        root.addView(codeLabel);

        editor = new EditText(this);
        editor.setGravity(Gravity.TOP | Gravity.LEFT);
        editor.setTypeface(Typeface.MONOSPACE);
        editor.setTextSize(13);
        editor.setTextColor(WHITE);
        editor.setHintTextColor(MUTED);
        editor.setBackground(panelBackground());
        editor.setPadding(dp(12), dp(10), dp(12), dp(12));
        editor.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        editor.setHorizontalScrollBarEnabled(true);
        editor.setHorizontallyScrolling(true);
        editor.setVerticalScrollBarEnabled(true);
        editor.setTextIsSelectable(true);
        editor.setSingleLine(false);
        LinearLayout.LayoutParams editorParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.25f);
        editorParams.bottomMargin = dp(8);
        root.addView(editor, editorParams);

        LinearLayout consoleHeader = new LinearLayout(this);
        consoleHeader.setGravity(Gravity.CENTER_VERTICAL);
        consoleHeader.addView(label("CONSOLA  /  SALIDA", 11, MUTED, true),
                new LinearLayout.LayoutParams(0, dp(32), 1f));
        Button clear = new Button(this);
        clear.setText("Limpiar");
        clear.setTextSize(10);
        clear.setAllCaps(false);
        clear.setTextColor(MUTED);
        clear.setPadding(dp(8), 0, dp(8), 0);
        clear.setMinHeight(0);
        clear.setMinimumHeight(0);
        clear.setBackground(panelBackground());
        clear.setOnClickListener(v -> console.setText(""));
        consoleHeader.addView(clear, new LinearLayout.LayoutParams(dp(80), dp(32)));
        root.addView(consoleHeader);

        outputScroll = new ScrollView(this);
        outputScroll.setFillViewport(true);
        outputScroll.setBackground(panelBackground());
        console = new TextView(this);
        console.setTextSize(12);
        console.setTextColor(GREEN);
        console.setTypeface(Typeface.MONOSPACE);
        console.setTextIsSelectable(true);
        console.setPadding(dp(12), dp(10), dp(12), dp(10));
        outputScroll.addView(console);
        root.addView(outputScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 0.85f));
    }

    private TextView label(String value, int sp, int color, boolean bold) {
        TextView text = new TextView(this);
        text.setText(value);
        text.setTextColor(color);
        text.setTextSize(sp);
        if (bold) text.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        text.setGravity(Gravity.CENTER_VERTICAL);
        return text;
    }

    private Button addButton(LinearLayout row, String title, int bg, Runnable onClick) {
        Button button = new Button(this);
        button.setText(title);
        button.setTextSize(11);
        button.setAllCaps(false);
        button.setTextColor(WHITE);
        button.setBackground(buttonBackground(bg));
        button.setPadding(dp(2), 0, dp(2), 0);
        button.setMinWidth(0);
        button.setMinimumWidth(0);
        button.setMinHeight(0);
        button.setMinimumHeight(0);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(40), 1f);
        params.rightMargin = dp(5);
        row.addView(button, params);
        button.setOnClickListener(v -> onClick.run());
        return button;
    }

    private GradientDrawable buttonBackground(int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(9));
        bg.setStroke(dp(1), BORDER);
        return bg;
    }

    private GradientDrawable panelBackground() {
        return buttonBackground(PANEL);
    }

    private int dp(int amount) {
        return (int) (amount * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void setStatus(String text, int color) {
        status.setText(text);
        status.setTextColor(color);
    }

    private void updateButtons() {
        if (playButton != null) {
            playButton.setEnabled(!running);
            playButton.setAlpha(running ? .45f : 1f);
        }
        if (stopButton != null) {
            stopButton.setEnabled(running && !stopping);
            stopButton.setAlpha(running && !stopping ? 1f : .45f);
        }
    }

    private void appendConsole(String text) {
        if (text == null || text.isEmpty()) return;
        StringBuilder sb = new StringBuilder(console.getText());
        sb.append(text);
        if (sb.length() > MAX_CONSOLE_CHARS) {
            sb.delete(0, sb.length() - MAX_CONSOLE_CHARS);
        }
        console.setText(sb);
        outputScroll.post(() -> outputScroll.fullScroll(View.FOCUS_DOWN));
    }

    private File getWorkspace() {
        File dir = new File(getFilesDir(), "workspace");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    private String sanitizeName(String requested) {
        if (requested == null) requested = "programa.py";
        String safe = requested.replaceAll("[^a-zA-Z0-9._-]", "_");
        safe = safe.replaceAll("^\\.+", "");
        if (safe.length() > 80) safe = safe.substring(0, 80);
        if (safe.isEmpty()) safe = "programa.py";
        if (!safe.toLowerCase().endsWith(".py")) safe += ".py";
        return safe;
    }

    private void newScript() {
        if (running) {
            toast("Det\u00e9n primero la ejecuci\u00f3n.");
            return;
        }
        selectedName = "programa_" + System.currentTimeMillis() + ".py";
        filename.setText(selectedName);
        editor.setText("# Escribe tu codigo Python 3\nprint('Hola, Android!')\n");
        setStatus("Nuevo archivo", ACCENT);
    }

    private void openDocument() {
        if (running) {
            toast("Det\u00e9n primero la ejecuci\u00f3n.");
            return;
        }
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, REQUEST_IMPORT);
    }

    private void exportDocument() {
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.setType("text/plain");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.putExtra(Intent.EXTRA_TITLE, sanitizeName(selectedName));
        startActivityForResult(intent, REQUEST_EXPORT);
    }

    @Override
    protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (result != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (request == REQUEST_IMPORT) {
            String name = getDocumentName(uri);
            if (!name.toLowerCase().endsWith(".py")) {
                toast("Elige un archivo con extensi\u00f3n .py");
                return;
            }
            try (InputStream input = getContentResolver().openInputStream(uri)) {
                if (input == null) throw new IllegalArgumentException("No se pudo abrir el archivo.");
                byte[] bytes = readAtMost(input, MAX_SCRIPT_BYTES);
                selectedName = sanitizeName(name);
                filename.setText(selectedName);
                editor.setText(new String(bytes, StandardCharsets.UTF_8));
                saveScript();
                setStatus("Archivo importado", GREEN);
            } catch (Exception error) {
                new AlertDialog.Builder(this).setTitle("Error al importar")
                        .setMessage(error.getMessage()).setPositiveButton("Aceptar", null).show();
            }
        } else if (request == REQUEST_EXPORT) {
            try (OutputStream out = getContentResolver().openOutputStream(uri, "wt")) {
                if (out == null) throw new IllegalArgumentException("No se puede guardar.");
                out.write(editor.getText().toString().getBytes(StandardCharsets.UTF_8));
                out.flush();
                toast("Archivo .py exportado");
            } catch (Exception error) {
                toast("Error al exportar: " + error.getMessage());
            }
        }
    }

    private String getDocumentName(Uri uri) {
        try (Cursor cursor = getContentResolver().query(uri,
                new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                String name = cursor.getString(0);
                if (name != null) return name;
            }
        } catch (Exception ignored) { }
        return "archivo.py";
    }

    private static byte[] readAtMost(InputStream in, int maximum) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[4096];
        int size;
        while ((size = in.read(buffer)) != -1) {
            if (out.size() + size > maximum) {
                throw new IllegalArgumentException("El archivo supera 1 MB.");
            }
            out.write(buffer, 0, size);
        }
        return out.toByteArray();
    }

    private void saveScript() {
        selectedName = sanitizeName(selectedName);
        filename.setText(selectedName);
        try {
            File file = new File(getWorkspace(), selectedName);
            byte[] bytes = editor.getText().toString().getBytes(StandardCharsets.UTF_8);
            if (bytes.length > MAX_SCRIPT_BYTES) {
                toast("Codigo demasiado grande (m\u00e1ximo 1 MB).");
                return;
            }
            try (FileOutputStream out = new FileOutputStream(file)) {
                out.write(bytes);
            }
            getPreferences(MODE_PRIVATE).edit().putString("last", selectedName).apply();
            setStatus("Guardado", GREEN);
        } catch (Exception e) {
            toast("No se pudo guardar: " + e.getMessage());
        }
    }

    private void loadLocal(File file) throws Exception {
        try (FileInputStream input = new FileInputStream(file)) {
            byte[] content = readAtMost(input, MAX_SCRIPT_BYTES);
            selectedName = file.getName();
            filename.setText(selectedName);
            editor.setText(new String(content, StandardCharsets.UTF_8));
            getPreferences(MODE_PRIVATE).edit().putString("last", selectedName).apply();
            setStatus("Archivo cargado", GREEN);
        }
    }

    private void showLibrary() {
        if (running) {
            toast("Det\u00e9n primero la ejecuci\u00f3n.");
            return;
        }
        File[] files = getWorkspace().listFiles((dir, name) -> name.endsWith(".py"));
        if (files == null || files.length == 0) {
            toast("A\u00fan no hay scripts guardados.");
            return;
        }
        Arrays.sort(files, Comparator.comparing(File::getName));
        String[] items = new String[files.length];
        for (int i = 0; i < files.length; i++) items[i] = files[i].getName();
        new AlertDialog.Builder(this).setTitle("Mis scripts Python")
                .setItems(items, (dialog, selected) -> {
                    try {
                        loadLocal(files[selected]);
                    } catch (Exception error) {
                        toast("Error: " + error.getMessage());
                    }
                })
                .setNegativeButton("Cerrar", null).show();
    }

    private void execute() {
        if (running) return;
        saveScript();
        File script = new File(getWorkspace(), selectedName);
        if (!script.isFile()) {
            toast("No se encontr\u00f3 el archivo para ejecutar.");
            return;
        }
        running = true;
        stopping = false;
        updateButtons();
        appendConsole("\n>>> Ejecutar: " + selectedName + "\n");
        setStatus("Conectando...", ACCENT);
        if (bound) {
            sendRun();
        } else {
            startWhenConnected = true;
            if (!bindService(new Intent(this, PyRunnerService.class), connection, Context.BIND_AUTO_CREATE)) {
                running = false;
                startWhenConnected = false;
                updateButtons();
                setStatus("No se pudo iniciar el servicio", RED);
            }
        }
    }

    private void sendRun() {
        Message message = Message.obtain(null, Protocol.RUN);
        message.replyTo = incoming;
        Bundle bundle = new Bundle();
        bundle.putString("path", new File(getWorkspace(), selectedName).getAbsolutePath());
        message.setData(bundle);
        try {
            service.send(message);
        } catch (Exception error) {
            running = false;
            updateButtons();
            setStatus("Error de conexi\u00f3n", RED);
            appendConsole("\n[Error] " + error + "\n");
        }
    }

    private void stopRunning() {
        if (!running) return;
        stopping = true;
        updateButtons();
        setStatus("Deteniendo...", MUTED);
        sendToService(Protocol.STOP, new Bundle());
    }

    private void showInputPrompt() {
        if (!running || isFinishing()) return;
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setTextColor(Color.BLACK);
        input.setHint("Dato solicitado por input()");
        input.setInputType(InputType.TYPE_CLASS_TEXT);
        LinearLayout holder = new LinearLayout(this);
        holder.setPadding(dp(16), 0, dp(16), 0);
        holder.addView(input, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle("Entrada de Python")
                .setView(holder)
                .setCancelable(false)
                .setPositiveButton("Enviar", (dialog, which) -> replyInput(input.getText().toString(), false))
                .setNegativeButton("Cancelar", (dialog, which) -> replyInput("", true));
        inputDialog = builder.create();
        inputDialog.setOnDismissListener(dialog -> inputDialog = null);
        inputDialog.getWindow();
        inputDialog.show();
    }

    private void replyInput(String value, boolean cancelled) {
        if (!running) return;
        Bundle input = new Bundle();
        input.putString("value", value);
        input.putBoolean("cancel", cancelled);
        appendConsole(cancelled ? "[Entrada cancelada]\n" : value + "\n");
        sendToService(Protocol.INPUT_REPLY, input);
    }

    private void sendToService(int type, Bundle data) {
        Messenger receiver = service;
        if (receiver == null || !bound) return;
        Message message = Message.obtain(null, type);
        message.setData(data);
        try {
            receiver.send(message);
        } catch (RemoteException error) {
            appendConsole("\n[El servicio no responde]\n");
        }
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        if (inputDialog != null) inputDialog.dismiss();
        if (bound) {
            try {
                unbindService(connection);
            } catch (Exception ignored) { }
            bound = false;
        }
        super.onDestroy();
    }
}
