package com.archmoba.pyconsole;

final class Protocol {
    static final int RUN = 1;
    static final int STOP = 2;
    static final int INPUT_REPLY = 3;

    static final int OUTPUT = 11;
    static final int STATUS = 12;
    static final int FINISHED = 13;
    static final int INPUT_REQUEST = 14;

    private Protocol() { }
}
