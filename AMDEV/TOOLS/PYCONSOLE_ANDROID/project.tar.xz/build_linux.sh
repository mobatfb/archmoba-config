#!/bin/sh
set -eu
if ! command -v gradle >/dev/null 2>&1; then
    echo 'Se requiere Gradle 8.11.1 y Android SDK 35.' >&2
    exit 1
fi
gradle :app:assembleDebug
printf '%s\n' 'APK: app/build/outputs/apk/debug/app-debug.apk'
