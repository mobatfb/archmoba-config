# AMDEV Android v0.3 - Native Launcher + Python 3 Console

This app adapts **AMDEV 1.0.23** (original desktop Tkinter launcher)
to native Android interface written in Java. It also includes the prior
**PyConsole v0.2**, using Chaquopy CPython 3.11 in an isolated service.

## Native Android UI

- Main application screen with AMDEV identity, app cards and version labels.
- Reads `AMDEV/apps.json` live from the official GitHub repository.
- Hides any app whose `active` field is false.
- Keeps a last-known-good cache, and bundles a fallback catalog for offline use.
- App tap selects the item and loads its individual `config.json`.
- Displays maintenance, version, path, description and fixed release URL.
- Has AMDEV floating menu INSIDE the app (no system-wide overlay permission).
- Quick navigation to a standalone Python 3 console with file editor.
- Open exact repo script into console to inspect/edit it.
- Scripts are NOT automatically executed by selecting a repository app.

## Python 3 console

- CPython 3.11 embedded through Chaquopy 17.2.
- Import, edit, save, export, execute and stop `.py` scripts.
- Supports `input()` dialogs and captures stdout/stderr.
- `run URL`, `open URL`, `python3 URL` for GitHub-hosted `.py` scripts.
- Security: HTTPS GitHub only, 1MB max source, isolated Python process.
- If a downloaded script needs Tkinter/PyQt/Pyglet, it is displayed but
  is NOT auto-executed since a desktop GUI cannot render on Android.

## Important compatibility note

Only the **AMDEV launcher interface** itself is ported to Android.
PTM, PYRION and PYRION EDIT remain listed in the catalog; their
own desktop GUI implementations require independent mobile ports.
The original `AMDEV/app.py` still exists unchanged in the repo.

The Android package name is `com.archmoba.amdev.mobile`, allowing
installation alongside older `com.archmoba.pyconsole` versions.

## Build

Requirements: JDK 17, Android SDK platform 35, Gradle 8.11.1,
Python 3.11 and internet at build time to resolve Chaquopy.

`gradle --no-daemon :app:assembleDebug`

The GitHub Actions workflow in branch `feature/android-pyconsole` can
build this project by unpacking `project.tar.xz` then running Gradle.

## Testing

- Verify Android app launch into native AMDEV list.
- With internet, verify live catalog and config loading.
- Offline, verify catalog fallback/cache still renders.
- From app card, open source `.py` into the Python console.
- Verify a simple Python script and `input()` then Stop button.
- Confirm desktop-GUI scripts do not pretend to render on Android.
