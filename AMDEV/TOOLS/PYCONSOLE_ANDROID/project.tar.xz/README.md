# AMDEV Android v0.4.0 - AMDEV + PTM interfaces nativas

Aplicacion Android con CPython 3.11 integrado (Chaquopy). No requiere Tkinter.

## Correccion al error reportado

`PTM/app.py` tiene 209939 bytes en GitHub y utiliza `tkinter` de escritorio.
En v0.3, la consola lo descargaba y al pulsar Ejecutar fallaba con
`ModuleNotFoundError: No module named tkinter`.

En v0.4, los enlaces de AMDEV/app.py y PTM/app.py del repositorio
`mobatfb/archmoba-dev` abren sus propias actividades Android, sin ejecutar
los archivos Tkinter. La misma deteccion funciona al pulsar Ejecutar sobre
el texto descargado en el editor. Para otros programas de escritorio, el
boton Ejecutar muestra una alerta en lugar del traceback.

## Funciones

- AMDEV Android: catalogo remoto AMDEV/apps.json, caché, seleccion y detalles.
- PTM Android: catalogo remoto PTM/guide.csv, cache y respaldo integrado,
  buscador de 40 caracteres, categorias, favoritos, recientes, mas usados,
  recomendados, pestañas de herramientas y detalles. Mantiene versiones, rutas
  y palabras clave del repositorio, no inventa interfaces.
- Acceso a PTM desde tarjeta de AMDEV o comando `ptm` de la consola.
- Consola Python 3: editor, importacion, exportacion, ejecucion, input(),
  logs, detener y descarga de scripts .py alojados en GitHub.
- Para abrir PTM desde la consola:
  `run https://raw.githubusercontent.com/mobatfb/archmoba-dev/main/PTM/app.py`
- Para abrir AMDEV desde la consola:
  `run https://raw.githubusercontent.com/mobatfb/archmoba-dev/main/AMDEV/app.py`

## Alcance actual

La interfaz de lanzadores AMDEV y PTM es nativa. NO se han convertido
las ventanas Tkinter de cada herramienta individual (p. ej. reproductor MP3,
ENTER, PYRION EDIT y Solitario). El catalogo permite consultar sus fichas,
abrir el codigo PY en la consola y ejecutar scripts compatibles sin GUI.
Los paquetes ZIP de varias partes no se ejecutan como un solo script.

## Compilacion

JDK 17, Android SDK 35, Gradle 8.11.1, Python 3.11.
`gradle --no-daemon :app:assembleDebug`

APK debug firmado para instalacion de prueba, target SDK 34, ABI armv7/arm64,
minimo Android 7.0. Distribucion al publico requiere firma y pruebas en
un dispositivo fisico.

## Pruebas

`python3 -m unittest discover -s tests -v`

Abrir AMDEV, entrar a PTM, buscar herramientas, alternar favoritos y pestañas.
Desde la consola pegar el enlace PTM/app.py y verificar que abra el PTM nativo.
Pulsar Ejecutar sobre un .py descargado que usa Tkinter y verificar
que se maneje sin traceback. Se recomienda probar tambien sin internet.
