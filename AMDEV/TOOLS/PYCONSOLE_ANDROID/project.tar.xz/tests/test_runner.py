"""Desktop tests of the Python runner with a fake Android bridge."""
import os
import pathlib
import sys
import tempfile
import unittest

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / 'app' / 'src' / 'main' / 'python'))
from py_runner import execute_file


class Bridge:
    def __init__(self, inputs=()):
        self.messages = []
        self.inputs = iter(inputs)
        self.flushes = 0

    def output(self, text):
        self.messages.append(text)

    def flushNow(self):
        self.flushes += 1

    def requestInput(self):
        return next(self.inputs, None)

    @property
    def text(self):
        return ''.join(self.messages)


class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.home = pathlib.Path(self.temp.name)
        self.ws = self.home / 'workspace'
        self.ws.mkdir()

    def tearDown(self):
        self.temp.cleanup()

    def write(self, name, content):
        path = self.ws / name
        path.write_text(content, encoding='utf-8')
        return str(path)

    def test_print_version(self):
        bridge = Bridge()
        script = self.write('ok.py', 'import sys\nprint("PY:", sys.version_info.major)\n')
        self.assertEqual(execute_file(script, str(self.home), bridge), 0)
        self.assertIn('PY: 3', bridge.text)

    def test_input(self):
        bridge = Bridge(['Ana'])
        script = self.write('input.py', 'name = input("Nombre: ")\nprint("Hola", name)\n')
        self.assertEqual(execute_file(script, str(self.home), bridge), 0)
        self.assertIn('Hola Ana', bridge.text)
        self.assertIn('Nombre: ', bridge.text)

    def test_traceback(self):
        bridge = Bridge()
        script = self.write('fail.py', 'raise ValueError("prueba")\n')
        self.assertEqual(execute_file(script, str(self.home), bridge), 1)
        self.assertIn('ValueError: prueba', bridge.text)
        self.assertIn('fail.py', bridge.text)

    def test_import_sibling(self):
        self.write('utils.py', 'def value(): return 42\n')
        bridge = Bridge()
        script = self.write('main.py', 'import utils\nprint(utils.value())\n')
        self.assertEqual(execute_file(script, str(self.home), bridge), 0)
        self.assertIn('42', bridge.text)

    def test_deny_outside_workspace(self):
        bridge = Bridge()
        outside = self.home / 'outside.py'
        outside.write_text('print("bad")', encoding='utf-8')
        self.assertEqual(execute_file(str(outside), str(self.home), bridge), 1)
        self.assertIn('workspace', bridge.text)


if __name__ == '__main__':
    unittest.main()
