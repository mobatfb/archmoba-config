import csv
from pathlib import Path
import unittest

PROJECT = Path(__file__).resolve().parents[1]


class PtmAssetsTests(unittest.TestCase):
    def test_fallback_rows_have_valid_schema(self):
        path = PROJECT / 'app/src/main/assets/ptm_guide.csv'
        with path.open(encoding='utf-8') as stream:
            reader = csv.DictReader(stream, delimiter=';')
            rows = list(reader)
        self.assertGreaterEqual(len(rows), 8)
        for row in rows:
            self.assertEqual(row['activo'], '1')
            self.assertTrue(row['ruta'].startswith('tools/'))
            self.assertEqual(row['autor'], 'ARCHMOBA')

    def test_native_ptm_is_registered(self):
        manifest = (PROJECT / 'app/src/main/AndroidManifest.xml').read_text()
        self.assertIn('android:name=".PTMActivity"', manifest)
        main = (PROJECT / 'app/src/main/java/com/archmoba/pyconsole/MainActivity.java').read_text()
        self.assertIn('routeKnownNativeUrl(finalUrl)', main)
        self.assertIn('routeOrBlockDesktopGui(editor.getText().toString())', main)
        self.assertIn('PTMActivity.class', main)


if __name__ == '__main__':
    unittest.main()
