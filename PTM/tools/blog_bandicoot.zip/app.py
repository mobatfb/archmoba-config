import tkinter as tk
from pathlib import Path

# Blog Bandicoot - hecho como lo haria un principiante.
# No conoce PTM: solo crea una aplicacion Tkinter normal.

BG = "#0f1720"
PANEL = "#17232f"
ORANGE = "#ff6a00"
GOLD = "#ffc928"
TEXT = "#f7f7f7"
MUTED = "#c5ced6"
GREEN = "#5ecb72"

root = tk.Tk()
root.title("Blog Bandicoot")
root.geometry("1050x700")
root.minsize(820, 560)
root.configure(bg=BG)

base_dir = Path(__file__).resolve().parent

# Encabezado
header = tk.Frame(root, bg="#111b24", height=76)
header.pack(fill="x")
header.pack_propagate(False)

tk.Label(
    header,
    text="BLOG BANDICOOT",
    bg="#111b24",
    fg=GOLD,
    font=("Segoe UI", 22, "bold"),
).pack(side="left", padx=24)

tk.Label(
    header,
    text="Wumpas, cajas, islas y puro caos",
    bg="#111b24",
    fg=MUTED,
    font=("Segoe UI", 10),
).pack(side="left", padx=(0, 20))

# Navegacion
nav = tk.Frame(root, bg=ORANGE)
nav.pack(fill="x")

content = tk.Frame(root, bg=BG)
content.pack(fill="both", expand=True)

sections = {}
nav_buttons = {}


def make_page(name):
    page = tk.Frame(content, bg=BG)
    sections[name] = page
    return page


def show_page(name):
    for page in sections.values():
        page.pack_forget()
    sections[name].pack(fill="both", expand=True)
    for key, button in nav_buttons.items():
        button.configure(bg=GOLD if key == name else ORANGE, fg="#151515")


def add_nav(text, page_name):
    button = tk.Button(
        nav,
        text=text,
        command=lambda: show_page(page_name),
        bg=ORANGE,
        fg="#151515",
        activebackground=GOLD,
        relief="flat",
        bd=0,
        padx=14,
        pady=9,
        font=("Segoe UI", 9, "bold"),
        cursor="hand2",
    )
    button.pack(side="left")
    nav_buttons[page_name] = button


# INICIO
home = make_page("inicio")
hero = tk.Frame(home, bg=BG)
hero.pack(fill="both", expand=True, padx=28, pady=24)
hero.columnconfigure(0, weight=3)
hero.columnconfigure(1, weight=2)
hero.rowconfigure(0, weight=1)

left = tk.Frame(hero, bg=BG)
left.grid(row=0, column=0, sticky="nsew", padx=(0, 20))

tk.Label(left, text="¡WOAH! Bienvenido al Blog Bandicoot", bg=BG, fg=TEXT,
         font=("Segoe UI", 25, "bold"), anchor="w").pack(fill="x", pady=(16, 10))

tk.Label(
    left,
    text=(
        "Un rincón hecho por fans para recordar carreras imposibles, cajas TNT, "
        "frutas Wumpa, máscaras Aku Aku y todo lo que vuelve inolvidable a Crash Bandicoot."
    ),
    bg=BG, fg=MUTED, font=("Segoe UI", 12), wraplength=560,
    justify="left", anchor="w"
).pack(fill="x", pady=(0, 18))

facts = [
    ("3", "islas clásicas para perder la paciencia"),
    ("100+", "cajas que juraste haber roto"),
    ("∞", "veces diciendo: una partida más"),
]
for big, small in facts:
    card = tk.Frame(left, bg=PANEL, padx=16, pady=12)
    card.pack(fill="x", pady=5)
    tk.Label(card, text=big, bg=PANEL, fg=GOLD, font=("Segoe UI", 17, "bold")).pack(side="left")
    tk.Label(card, text=small, bg=PANEL, fg=TEXT, font=("Segoe UI", 10)).pack(side="left", padx=14)

right = tk.Frame(hero, bg=PANEL, padx=12, pady=12)
right.grid(row=0, column=1, sticky="nsew")
try:
    crash_image = tk.PhotoImage(file=str(base_dir / "assets" / "crash.png"))
    root.crash_image = crash_image
    tk.Label(right, image=crash_image, bg=PANEL).pack(expand=True)
except Exception:
    tk.Label(right, text="CRASH BANDICOOT", bg=PANEL, fg=GOLD,
             font=("Segoe UI", 22, "bold")).pack(expand=True)

# HISTORIA
history = make_page("historia")
tk.Label(history, text="Historia de Crash", bg=BG, fg=GOLD,
         font=("Segoe UI", 24, "bold")).pack(anchor="w", padx=30, pady=(28, 6))

timeline = [
    ("1996", "Crash Bandicoot", "El comienzo de la aventura en las islas y el enfrentamiento con Neo Cortex."),
    ("1997", "Cortex Strikes Back", "Más niveles, nuevas amenazas y una alianza bastante sospechosa."),
    ("1998", "Warped", "Viajes en el tiempo, motos, aviones y uno de los clásicos más recordados."),
    ("1999", "Crash Team Racing", "Las carreras se convirtieron en parte esencial del universo Bandicoot."),
    ("Actualidad", "Una saga que sigue viva", "Remakes, nuevas entregas y una comunidad que todavía grita WOAH."),
]
for year, title, desc in timeline:
    row = tk.Frame(history, bg=PANEL, padx=16, pady=10)
    row.pack(fill="x", padx=30, pady=5)
    tk.Label(row, text=year, width=10, bg=PANEL, fg=ORANGE,
             font=("Segoe UI", 12, "bold")).pack(side="left")
    body = tk.Frame(row, bg=PANEL)
    body.pack(side="left", fill="x", expand=True)
    tk.Label(body, text=title, bg=PANEL, fg=TEXT,
             font=("Segoe UI", 11, "bold"), anchor="w").pack(fill="x")
    tk.Label(body, text=desc, bg=PANEL, fg=MUTED,
             font=("Segoe UI", 9), anchor="w", justify="left", wraplength=720).pack(fill="x")

# PERSONAJES
characters = make_page("personajes")
tk.Label(characters, text="Personajes", bg=BG, fg=GOLD,
         font=("Segoe UI", 24, "bold")).pack(anchor="w", padx=30, pady=(28, 12))

char_data = [
    ("Crash", "El marsupial hiperactivo que resuelve casi todo girando."),
    ("Coco", "Ingeniosa, tecnológica y muchas veces la voz de la razón."),
    ("Aku Aku", "Máscara protectora, consejero y salvavidas oficial."),
    ("Dr. Neo Cortex", "Genio científico con planes enormes y resultados discutibles."),
    ("N. Gin", "Científico mecánico, leal a Cortex y fan de máquinas gigantes."),
    ("Dingodile", "Mitad dingo, mitad cocodrilo y cien por ciento problemas."),
]
char_grid = tk.Frame(characters, bg=BG)
char_grid.pack(fill="both", expand=True, padx=24, pady=6)
for i, (name, desc) in enumerate(char_data):
    card = tk.Frame(char_grid, bg=PANEL, padx=14, pady=14)
    card.grid(row=i // 2, column=i % 2, sticky="nsew", padx=6, pady=6)
    char_grid.columnconfigure(i % 2, weight=1)
    tk.Label(card, text=name, bg=PANEL, fg=ORANGE,
             font=("Segoe UI", 14, "bold"), anchor="w").pack(fill="x")
    tk.Label(card, text=desc, bg=PANEL, fg=MUTED,
             font=("Segoe UI", 10), wraplength=390, justify="left", anchor="w").pack(fill="x", pady=(5, 0))

# CURIOSIDADES
curiosities = make_page("curiosidades")
tk.Label(curiosities, text="Curiosidades Bandicoot", bg=BG, fg=GOLD,
         font=("Segoe UI", 24, "bold")).pack(anchor="w", padx=30, pady=(28, 12))

curiosity_list = [
    "Crash fue diseñado para destacar visualmente frente a fondos coloridos.",
    "Las cajas se convirtieron en una de las señas de identidad de la saga.",
    "Aku Aku puede proteger a Crash de ciertos golpes y peligros.",
    "Las gemas suelen premiar a quienes completan retos especiales en los niveles.",
    "CTR convirtió a muchos personajes de la saga en rivales de carreras.",
    "El grito 'WOAH' terminó siendo uno de los memes más reconocibles asociados al personaje.",
]
for number, text in enumerate(curiosity_list, 1):
    row = tk.Frame(curiosities, bg=PANEL, padx=14, pady=12)
    row.pack(fill="x", padx=30, pady=5)
    tk.Label(row, text=str(number), bg=ORANGE, fg="#151515", width=3,
             font=("Segoe UI", 11, "bold")).pack(side="left", padx=(0, 12))
    tk.Label(row, text=text, bg=PANEL, fg=TEXT,
             font=("Segoe UI", 10), anchor="w", justify="left", wraplength=780).pack(side="left", fill="x", expand=True)

# GUIA
guide = make_page("guia")
tk.Label(guide, text="Guía rápida para sobrevivir", bg=BG, fg=GOLD,
         font=("Segoe UI", 24, "bold")).pack(anchor="w", padx=30, pady=(28, 10))

tips = [
    ("Rompe cajas", "Si quieres completar los niveles al máximo, observa cada rincón."),
    ("No corras siempre", "Algunas trampas castigan más la prisa que la falta de habilidad."),
    ("Guarda Aku Aku", "Una máscara extra puede convertir un error en una segunda oportunidad."),
    ("Aprende patrones", "Muchos obstáculos tienen ritmos repetidos. Mira primero, salta después."),
    ("CTR: domina el derrape", "Encadenar turbos y mantener reservas puede marcar toda la carrera."),
]
for title, desc in tips:
    box = tk.Frame(guide, bg=PANEL, padx=16, pady=12)
    box.pack(fill="x", padx=30, pady=5)
    tk.Label(box, text=title, bg=PANEL, fg=GREEN,
             font=("Segoe UI", 12, "bold"), anchor="w").pack(fill="x")
    tk.Label(box, text=desc, bg=PANEL, fg=MUTED,
             font=("Segoe UI", 10), anchor="w", justify="left", wraplength=790).pack(fill="x", pady=(3, 0))

# GALERIA
gallery = make_page("galeria")
tk.Label(gallery, text="Galería", bg=BG, fg=GOLD,
         font=("Segoe UI", 24, "bold")).pack(anchor="w", padx=30, pady=(28, 12))
gal_box = tk.Frame(gallery, bg=PANEL, padx=18, pady=18)
gal_box.pack(fill="both", expand=True, padx=30, pady=(0, 30))
try:
    tk.Label(gal_box, image=root.crash_image, bg=PANEL).pack(pady=10)
except Exception:
    pass
tk.Label(gal_box, text="Crash Bandicoot", bg=PANEL, fg=TEXT,
         font=("Segoe UI", 15, "bold")).pack()
tk.Label(gal_box, text="La imagen viaja dentro del ZIP como un asset local.", bg=PANEL, fg=MUTED,
         font=("Segoe UI", 10)).pack(pady=(4, 10))

# ACERCA
about = make_page("acerca")
tk.Label(about, text="Acerca del blog", bg=BG, fg=GOLD,
         font=("Segoe UI", 24, "bold")).pack(anchor="w", padx=30, pady=(30, 10))
tk.Label(
    about,
    text=(
        "Este pequeño Blog Bandicoot está hecho únicamente con Python y Tkinter. "
        "El autor no necesita saber cómo funciona PTM: crea un programa normal, lo guarda junto a sus assets, "
        "lo comprime en ZIP y selecciona app.py como archivo principal."
    ),
    bg=BG, fg=TEXT, font=("Segoe UI", 12), wraplength=820, justify="left", anchor="w"
).pack(fill="x", padx=30, pady=10)

for text, page in [
    ("Inicio", "inicio"),
    ("Historia", "historia"),
    ("Personajes", "personajes"),
    ("Curiosidades", "curiosidades"),
    ("Guía", "guia"),
    ("Galería", "galeria"),
    ("Acerca", "acerca"),
]:
    add_nav(text, page)

show_page("inicio")
root.mainloop()
