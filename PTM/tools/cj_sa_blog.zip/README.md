# CJ SA Blog para PTM

Paquete web Flask. El archivo principal es `app.py`.

Al ejecutarse, selecciona un puerto local disponible, inicia el servidor y abre el navegador automáticamente.
