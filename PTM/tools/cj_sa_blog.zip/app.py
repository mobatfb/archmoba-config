import tkinter as tk
from pathlib import Path

ROOT=Path(__file__).resolve().parent
BG='#10140f'; PANEL='#192219'; GREEN='#4f9b49'; DARK='#2c6631'; TEXT='#f4f1e8'; MUTED='#b9c2b5'; GOLD='#d2ad55'
JOKES=[
('CJ y el gimnasio','CJ entró al gimnasio. Cinco minutos después salió diciendo: All you had to do was seguir la rutina, CJ.'),
('GPS de Los Santos','El GPS dijo: gira a la derecha. CJ respondió: mejor sigo el tren, seguro sale bien.'),
('Misión rápida','CJ salió por pan. Volvió tres horas después con una moto, dos estrellas y cero pan.'),
('CJ programador','CJ encontró un bug y solo dijo: Ah, shit... here we go again.'),
]
STORIES=[
('Llegar temprano','CJ salió con una hora de anticipación. Una bici, un taxi y una persecución después, llegó una hora tarde.'),
('La compra rápida','La misión era comprar refrescos. CJ regresó con un camión. Nadie preguntó de dónde salió.'),
('CJ descubre Internet','Buscó una guía para una misión y encontró a alguien completándola sin recibir un disparo. Cerró el navegador por respeto propio.'),
]
QUOTES=['Si una misión parece fácil, todavía no empezó la persecución.','Todo plan es perfecto hasta que CJ encuentra una moto.','Grove Street enseña a no subestimar una bicicleta verde.','Hay días tranquilos. CJ todavía no ha encontrado ninguno.']

class Blog(tk.Frame):
    def __init__(self,parent,app=None):
        super().__init__(parent,bg=BG); self.app=app; self.photo=None; self.buttons={}
        top=tk.Frame(self,bg=PANEL,height=55); top.pack(fill='x'); top.pack_propagate(False)
        tk.Label(top,text='CJ',bg=PANEL,fg=TEXT,font=('Arial Black',18)).pack(side='left',padx=(15,2))
        tk.Label(top,text='SA BLOG',bg=PANEL,fg=GREEN,font=('Segoe UI',11,'bold')).pack(side='left')
        for n in ['Inicio','Chistes','Historias','Frases','Galería','Acerca']:
            b=tk.Button(top,text=n,command=lambda x=n:self.show(x),bg=PANEL,fg=TEXT,activebackground=DARK,activeforeground='white',relief='flat',bd=0,padx=10,font=('Segoe UI',9,'bold'),cursor='hand2'); b.pack(side='left',fill='y'); self.buttons[n]=b
        tk.Frame(self,bg=GREEN,height=3).pack(fill='x')
        self.canvas=tk.Canvas(self,bg=BG,highlightthickness=0); sb=tk.Scrollbar(self,command=self.canvas.yview); self.canvas.configure(yscrollcommand=sb.set); sb.pack(side='right',fill='y'); self.canvas.pack(fill='both',expand=True)
        self.body=tk.Frame(self.canvas,bg=BG); self.win=self.canvas.create_window((0,0),window=self.body,anchor='nw')
        self.body.bind('<Configure>',lambda e:self.canvas.configure(scrollregion=self.canvas.bbox('all'))); self.canvas.bind('<Configure>',lambda e:self.canvas.itemconfigure(self.win,width=e.width)); self.canvas.bind_all('<MouseWheel>',lambda e:self.canvas.yview_scroll(int(-e.delta/120),'units'))
        self.show('Inicio')
    def clear(self):
        for w in self.body.winfo_children(): w.destroy()
        self.canvas.yview_moveto(0)
    def title(self,t,s=''):
        tk.Label(self.body,text=t,bg=BG,fg=TEXT,font=('Arial Black',23),anchor='w').pack(fill='x',padx=25,pady=(23,3))
        if s: tk.Label(self.body,text=s,bg=BG,fg=MUTED,font=('Segoe UI',10),anchor='w').pack(fill='x',padx=25,pady=(0,12))
    def card(self,t,b,c=GREEN):
        f=tk.Frame(self.body,bg=PANEL,highlightbackground='#304030',highlightthickness=1); f.pack(fill='x',padx=25,pady=6); tk.Frame(f,bg=c,width=5).pack(side='left',fill='y'); x=tk.Frame(f,bg=PANEL); x.pack(fill='both',expand=True,padx=13,pady=10); tk.Label(x,text=t,bg=PANEL,fg=TEXT,font=('Segoe UI',11,'bold'),anchor='w').pack(fill='x'); tk.Label(x,text=b,bg=PANEL,fg=TEXT,font=('Segoe UI',9),justify='left',anchor='w',wraplength=730).pack(fill='x',pady=(4,0))
    def image(self):
        try:
            self.photo=tk.PhotoImage(file=str(ROOT/'assets'/'cj.png')); return self.photo
        except tk.TclError:return None
    def show(self,n):
        self.clear()
        for k,b in self.buttons.items(): b.configure(bg=DARK if k==n else PANEL)
        if n=='Inicio':
            self.title('CJ SA BLOG','El rincón menos serio de Grove Street')
            row=tk.Frame(self.body,bg=BG); row.pack(fill='x',padx=25,pady=10); left=tk.Frame(row,bg=BG); left.pack(side='left',fill='both',expand=True)
            tk.Label(left,text='Chistes, historias y frases de las situaciones que solo CJ convierte en un día normal.',bg=BG,fg=TEXT,font=('Segoe UI',12),wraplength=520,justify='left').pack(anchor='w',pady=(8,15))
            for x in ['Chistes','Historias','Galería']: tk.Button(left,text=x.upper(),command=lambda s=x:self.show(s),bg=GREEN,fg='white',relief='flat',padx=12,pady=7,cursor='hand2').pack(side='left',padx=(0,7))
            im=self.image(); box=tk.Frame(row,bg=PANEL); box.pack(side='right',padx=15); tk.Label(box,image=im if im else '',text='' if im else 'CJ',bg=PANEL,fg=TEXT,font=('Arial Black',30)).pack(padx=12,pady=12)
            self.card('Chiste del día',JOKES[0][1],GOLD)
        elif n=='Chistes':
            self.title('Chistes de CJ','Humor directamente desde Los Santos')
            for t,b in JOKES:self.card(t,b)
        elif n=='Historias':
            self.title('Historias de Grove Street','Aventuras que probablemente no estaban en el guion')
            for t,b in STORIES:self.card(t,b,GOLD)
        elif n=='Frases':
            self.title('Frases','Sabiduría no oficial de Los Santos')
            for i,q in enumerate(QUOTES,1):self.card(f'#{i}',f'“{q}”',GOLD if i%2==0 else GREEN)
        elif n=='Galería':
            self.title('Galería','CJ, protagonista absoluto del blog'); im=self.image(); box=tk.Frame(self.body,bg=PANEL); box.pack(padx=25,pady=10); tk.Label(box,image=im if im else '',text='' if im else 'CJ',bg=PANEL,fg=TEXT,font=('Arial Black',30)).pack(padx=18,pady=18); tk.Label(box,text='CJ — Grove Street, Los Santos',bg=PANEL,fg=TEXT,font=('Segoe UI',10,'bold')).pack(pady=(0,15))
        else:
            self.title('Acerca','CJ SA Blog dentro de PTM'); self.card('Aplicación Python normal','Interfaz hecha con Tkinter. No usa Flask, servidor, navegador ni localhost.'); self.card('Paquete PTM','PTM extrae el ZIP y ejecuta app.py como archivo principal. La imagen se carga desde assets/cj.png.'); self.card('Autor','ARCHMOBA',GOLD)
    def on_close(self):
        try:self.canvas.unbind_all('<MouseWheel>')
        except tk.TclError:pass

App = Blog


if __name__ == '__main__':
    raise SystemExit('CJ SA Blog debe abrirse desde PTM dentro de una pestaña.')
