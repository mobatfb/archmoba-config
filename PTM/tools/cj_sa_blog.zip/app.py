from pathlib import Path
import socket
import threading
import webbrowser

from flask import Flask, render_template

BASE_DIR = Path(__file__).resolve().parent
app = Flask(__name__, template_folder=str(BASE_DIR / "templates"), static_folder=str(BASE_DIR / "static"))

JOKES = [
    {"title": "CJ y el GPS", "text": "CJ puso el GPS para volver al barrio. El GPS respondió: 'All we had to do was seguir la ruta marcada'."},
    {"title": "Cinco estrellas", "text": "CJ preguntó si el restaurante tenía cinco estrellas. Le dijeron que sí. CJ contestó: 'Perfecto, por un momento pensé que era la policía'."},
    {"title": "Dieta de Grove Street", "text": "CJ empezó una dieta: pidió una ensalada. Dos minutos después añadió: 'Y algo pequeño para acompañar... el menú completo'."},
    {"title": "Entrenamiento", "text": "CJ fue al gimnasio y preguntó cuánto tardaría en ponerse fuerte. El entrenador dijo: 'Depende'. CJ respondió: 'Entonces empiezo mañana, hoy tengo una bicicleta que seguir'."},
    {"title": "Trabajo remoto", "text": "CJ consiguió trabajo remoto. El jefe le pidió estar siempre disponible. Desde entonces responde: 'Estoy en Grove Street, pero conectado'."},
    {"title": "La misión fácil", "text": "Le dijeron a CJ que la misión era facilísima. CJ miró a cámara y preguntó: '¿Facilísima en qué parte del mapa?'."},
]

STORIES = [
    {"title": "El Wi-Fi de Grove Street", "text": "CJ decidió modernizar el barrio instalando Wi-Fi. Todo iba perfecto hasta que Sweet pidió la contraseña. CJ respondió que era 'GROVE4LIFE'. Diez minutos después medio Los Santos estaba conectado y Ryder culpaba a la antena."},
    {"title": "CJ abre un blog", "text": "Un día CJ decidió dejar las misiones por unas horas y abrir un blog. Publicó un chiste, una foto y una historia. Cuando vio las visitas dijo que por fin había una misión donde el marcador subía sin perseguir ningún tren."},
    {"title": "La entrega imposible", "text": "CJ aceptó llevar una pizza a dos calles. El mapa sugirió una ruta de veinte minutos, tres autopistas y una montaña. CJ cerró el mapa y caminó. Fue la misión más eficiente de su semana."},
]

QUOTES = [
    "En Grove Street hasta el lunes necesita una misión secundaria.",
    "Si el mapa dice 'cerca', CJ lleva provisiones para tres días.",
    "No todo problema se arregla con una bicicleta, pero vale la pena intentarlo.",
    "El verdadero checkpoint es recordar dónde estacionaste.",
    "Una buena misión empieza con café y termina sin cinco estrellas.",
    "Si algo sale mal, conviértelo en una historia para el blog.",
]

@app.route("/")
def home():
    return render_template("index.html", featured=JOKES[:3], stories=STORIES[:2])

@app.route("/chistes")
def jokes():
    return render_template("jokes.html", jokes=JOKES)

@app.route("/historias")
def stories():
    return render_template("stories.html", stories=STORIES)

@app.route("/frases")
def quotes():
    return render_template("quotes.html", quotes=QUOTES)

@app.route("/galeria")
def gallery():
    return render_template("gallery.html")

@app.route("/acerca")
def about():
    return render_template("about.html")


def _free_port():
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.bind(("127.0.0.1", 0))
        return sock.getsockname()[1]


def main():
    port = _free_port()
    url = f"http://127.0.0.1:{port}"
    threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    app.run(host="127.0.0.1", port=port, debug=False, use_reloader=False)


if __name__ == "__main__":
    main()
